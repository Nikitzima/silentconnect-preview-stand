/* =========================================================================
   SilentConnect Redesign v2 — Полная экосистема (1:1 с боевым сайтом):
   - Liquid Glass Segmented Controls с пружинной физикой перетаскивания (lift/drag/squash)
   - Анимированный пересчёт цифр (requestAnimationFrame) + Spotlight (.spot)
   - Интуитивная зона финальной цены (Итого к оплате + Старая цена + % скидки + ₽/мес + Выгода)
   - Автоскрытие мобильной панели .mbar при видимости #checkout
   - Полный блок FAQ + Все 5 экранов + Все модалки + Command Palette (⌘K)
   ========================================================================= */

(() => {
'use strict';

const $  = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => Array.from(r.querySelectorAll(s));
const fmt = n => new Intl.NumberFormat('ru-RU').format(Math.round(n));

const SUB_ID = 'sc_live_88f29a1d';
const SUB_IMPORT_URL = `https://sub.silentconnect.net/my-secret-sub/import/${SUB_ID}`;
const IMPORT_BASE = 'https://sub.silentconnect.net/my-secret-sub/import';
const importUrlFor = app => `${IMPORT_BASE}/${app}/${SUB_ID}`;

/* ---------- Всплывающие уведомления (Toast) ---------- */
let toastTimer = null;
function toast(msg, duration = 3000) {
  const t = $('#toast');
  if (!t) return;
  t.textContent = msg;
  t.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => t.classList.remove('show'), duration);
}
window.toast = toast;

/* ---------- Копирование в буфер обмена ---------- */
function copyToClipboard(text, successMsg = 'Скопировано в буфер обмена') {
  if (navigator.clipboard && window.isSecureContext) {
    navigator.clipboard.writeText(text)
      .then(() => toast(successMsg))
      .catch(() => fallbackCopy(text, successMsg));
  } else {
    fallbackCopy(text, successMsg);
  }
}
window.copyToClipboard = copyToClipboard;

function fallbackCopy(text, successMsg) {
  const ta = document.createElement('textarea');
  ta.value = text;
  ta.style.position = 'fixed';
  ta.style.opacity = '0';
  document.body.appendChild(ta);
  ta.select();
  try {
    document.execCommand('copy');
    toast(successMsg);
  } catch (err) {
    toast('Не удалось скопировать. Скопируйте вручную.');
  }
  document.body.removeChild(ta);
}

/* Обработка глобальных кликов по [data-copy-url], [data-toast], .cf-widget */
document.addEventListener('click', e => {
  const copyBtn = e.target.closest('[data-copy-url]');
  if (copyBtn) {
    e.preventDefault();
    copyToClipboard(copyBtn.dataset.copyUrl, 'Ссылка подписки скопирована!');
    return;
  }
  const toastBtn = e.target.closest('[data-toast]');
  if (toastBtn) {
    const row = toastBtn.closest('.copy-row');
    const inp = row ? $('input', row) : null;
    if (inp && inp.value) copyToClipboard(inp.value, toastBtn.dataset.toast);
    else toast(toastBtn.dataset.toast);
  }
  const cf = e.target.closest('.cf-widget');
  if (cf) {
    const cur = cf.getAttribute('data-checked') === 'true';
    cf.setAttribute('data-checked', String(!cur));
    cf.setAttribute('aria-checked', String(!cur));
  }
});

/* ---------- Spotlight (.spot) курсорное свечение на ПК ---------- */
if (window.matchMedia('(pointer: fine)').matches) {
  document.addEventListener('pointermove', e => {
    const card = e.target.closest && e.target.closest('.spot');
    if (!card) return;
    const r = card.getBoundingClientRect();
    card.style.setProperty('--mx', (e.clientX - r.left) + 'px');
    card.style.setProperty('--my', (e.clientY - r.top) + 'px');
  }, { passive: true });
}

/* ---------- Генератор SVG QR-кода ---------- */
function renderSvgQr(text, containerEl, size = 164) {
  if (!containerEl) return;
  let hash = 0;
  for (let i = 0; i < text.length; i++) hash = ((hash << 5) - hash) + text.charCodeAt(i) | 0;
  const dim = 25;
  const cellSize = size / dim;
  let paths = '';

  function drawFinder(ox, oy) {
    paths += `<rect x="${ox * cellSize}" y="${oy * cellSize}" width="${7 * cellSize}" height="${7 * cellSize}" fill="#fff" rx="3"/>`;
    paths += `<rect x="${(ox + 1) * cellSize}" y="${(oy + 1) * cellSize}" width="${5 * cellSize}" height="${5 * cellSize}" fill="#080e0c"/>`;
    paths += `<rect x="${(ox + 2) * cellSize}" y="${(oy + 2) * cellSize}" width="${3 * cellSize}" height="${3 * cellSize}" fill="#34e3a4" rx="2"/>`;
  }
  drawFinder(1, 1);
  drawFinder(dim - 8, 1);
  drawFinder(1, dim - 8);

  for (let r = 0; r < dim; r++) {
    for (let c = 0; c < dim; c++) {
      if ((r < 9 && c < 9) || (r < 9 && c >= dim - 9) || (r >= dim - 9 && c < 9)) continue;
      const bit = ((hash ^ (r * 31 + c * 17)) & (1 << ((r + c) % 8))) !== 0;
      if (bit) {
        paths += `<rect x="${c * cellSize}" y="${r * cellSize}" width="${cellSize * 0.9}" height="${cellSize * 0.9}" fill="#34e3a4" rx="1.5" opacity="0.9"/>`;
      }
    }
  }

  containerEl.innerHTML = `<svg width="${size}" height="${size}" viewBox="0 0 ${size} ${size}" style="display:block;margin:0 auto">${paths}</svg>`;
}

/* ---------- Навигация & Автоскрытие нижней панели .mbar у чекаута ---------- */
const navEl = $('#nav');
function syncNavScroll() {
  if (navEl) navEl.classList.toggle('solid', window.scrollY > 20);
}
window.addEventListener('scroll', syncNavScroll, { passive: true });
syncNavScroll();

const mbarEl = $('#mbar');
const checkoutEl = $('#checkout');
if (mbarEl && checkoutEl && 'IntersectionObserver' in window) {
  new IntersectionObserver(entries => {
    mbarEl.classList.toggle('hide-bar', entries[0].isIntersecting);
  }, { threshold: 0.12 }).observe(checkoutEl);
}

/* ---------- Drag-to-scroll для горизонтальных вкладок ---------- */
function setupDraggableTrack(track) {
  if (!track || track._dragInit) return;
  track._dragInit = true;
  let isDown = false, startX = 0, scrollLeft = 0, moved = false;
  track.addEventListener('mousedown', e => {
    isDown = true;
    startX = e.pageX - track.offsetLeft;
    scrollLeft = track.scrollLeft;
    moved = false;
  });
  window.addEventListener('mouseup', () => { isDown = false; });
  track.addEventListener('mousemove', e => {
    if (!isDown) return;
    e.preventDefault();
    const x = e.pageX - track.offsetLeft;
    const walk = (x - startX) * 1.5;
    if (Math.abs(walk) > 4) moved = true;
    track.scrollLeft = scrollLeft - walk;
  });
  track.addEventListener('click', e => {
    if (moved) { e.preventDefault(); e.stopPropagation(); }
  }, true);
}

function centerActiveTab(track) {
  if (!track) return;
  const act = track.querySelector('.active') || track.querySelector('.on');
  if (act && track.scrollWidth > track.clientWidth) {
    track.scrollTo({ left: act.offsetLeft - (track.clientWidth - act.offsetWidth) / 2, behavior: 'smooth' });
  }
}

/* =========================================================================
   1. ПЛАТФОРМЫ И АВТООПРЕДЕЛЕНИЕ (subjson-service/app.py)
   ========================================================================= */
const OS_META = (window.SC_OS && window.SC_OS.length) ? window.SC_OS : [
  { id: 'ios', label: 'iOS', svg: '<svg viewBox="0 0 24 24" width="18" height="18" fill="currentColor"><path d="M18.71 19.5c-.83 1.24-1.71 2.45-3.05 2.47-1.34.03-1.77-.79-3.29-.79-1.53 0-2 .77-3.27.82-1.31.05-2.3-1.32-3.14-2.53C4.25 17 2.94 12.45 4.7 9.39c.87-1.52 2.43-2.48 4.12-2.51 1.28-.02 2.5.87 3.29.87.78 0 2.26-1.07 3.81-.91.65.03 2.47.26 3.64 1.98-.09.06-2.17 1.28-2.15 3.81.03 3.02 2.65 4.03 2.68 4.04-.03.07-.42 1.44-1.38 2.83M15.97 6.37c.62-.75 1.04-1.8 0.92-2.85-.9.04-1.99.6-2.64 1.36-.57.65-1.07 1.72-.94 2.74 1.01.08 2.04-.5 2.66-1.25z"/></svg>' },
  { id: 'android', label: 'Android', svg: '<svg viewBox="0 0 24 24" width="18" height="18" fill="currentColor"><path d="M17.52 15.34c-.55 0-1-.45-1-1s.45-1 1-1 1 .45 1 1-.45 1-1 1m-11.04 0c-.55 0-1-.45-1-1s.45-1 1-1 1 .45 1 1-.45 1-1 1m11.4-6.02l2-3.46c.12-.2.05-.47-.15-.57-.2-.12-.47-.05-.57.15l-2.02 3.5C15.59 8.41 13.85 8.08 12 8.08s-3.59.33-5.14.87L4.84 5.45c-.1-.2-.37-.27-.57-.15-.2.1-.27.37-.15.57l2 3.46C2.69 11.19.34 14.66 0 18.76h24c-.34-4.1-2.69-7.57-6.12-9.44"/></svg>' },
  { id: 'windows', label: 'Windows', svg: '<svg viewBox="0 0 24 24" width="18" height="18" fill="currentColor"><path d="M0 3.45L9.75 2.1v9.45H0m10.95-9.6L24 0v11.4H10.95M0 12.6h9.75v9.45L0 20.7M10.95 12.6H24V24l-13.05-1.8"/></svg>' },
  { id: 'macos', label: 'macOS', svg: '<svg viewBox="0 0 512 512" width="18" height="18"><rect width="512" height="512" fill="#dbe9f4" rx="85"/><path fill="#1e73f2" d="m0 0h262q-65 162-64 286c0 7 6 13 13 13h64q-6 113 28 213H0z"/></svg>' },
  { id: 'linux', label: 'Linux', svg: '<svg viewBox="0 0 24 24" width="18" height="18" fill="currentColor"><circle cx="12" cy="12" r="9"/></svg>' },
  { id: 'androidtv', label: 'Android TV', svg: '<svg viewBox="0 0 24 24" width="18" height="18" fill="currentColor"><path d="M22 3H2c-.6 0-1 .4-1 1v13c0 .6.4 1 1 1h8v1.5H7c-.3 0-.5.2-.5.5s.2.5.5.5h10c.3 0 .5-.2.5-.5s-.2-.5-.5-.5h-3V18h8c.6 0 1-.4 1-1V4c0-.6-.4-1-1-1zm-.2 13.8H2.2V4.2h19.6v12.6z"/></svg>' },
  { id: 'appletv', label: 'Apple TV', svg: '<svg viewBox="0 0 24 24" width="18" height="18" fill="currentColor"><path d="M22 3H2c-.6 0-1 .4-1 1v13c0 .6.4 1 1 1h8v1.5H7c-.3 0-.5.2-.5.5s.2.5.5.5h10c.3 0 .5-.2.5-.5s-.2-.5-.5-.5h-3V18h8c.6 0 1-.4 1-1V4c0-.6-.4-1-1-1zm-.2 13.8H2.2V4.2h19.6v12.6z"/></svg>' }
];
const OS_LABEL = {};
OS_META.forEach(o => { OS_LABEL[o.id] = o.label; });

function detectPlatform() {
  const ua = navigator.userAgent || '';
  const pf = navigator.platform || '';
  if (/iPad|iPhone|iPod/i.test(ua)) return 'ios';
  if (/Android/i.test(ua)) return /TV|AFT|BRAVIA|SMART-TV/i.test(ua) ? 'androidtv' : 'android';
  if (/Windows/i.test(ua)) return 'windows';
  if (/Mac/i.test(pf)) return 'macos';
  if (/Linux/i.test(pf)) return 'linux';
  return 'windows';
}
const detectedOs = detectPlatform();
['detectedOsMain', 'detectedOsAwg', 'detectedOsOf'].forEach(id => {
  const el = $('#' + id);
  if (el) el.textContent = OS_LABEL[detectedOs] || detectedOs;
});

/* =========================================================================
   2. ТАРИФНЫЙ КАЛЬКУЛЯТОР И ОФОРМЛЕНИЕ ЗАКАЗА (vpn_shop/catalog.py)
   ========================================================================= */
const CFG = {
  names:  { 3: 'Личный', 6: 'Домашний', 9: 'Расширенный' },
  awg:    { 3: 250, 6: 500, 9: 1000 },
  prices: { 3: { 1: 149, 3: 399, 6: 719, 12: 1249 },
            6: { 1: 199, 3: 539, 6: 959, 12: 1669 },
            9: { 1: 239, 3: 629, 6: 1129, 12: 1969 } },
  label:  { 1: '1 мес', 3: '3 мес', 6: '6 мес', 12: '12 мес' },
  full:   { 1: '1 месяц', 3: '3 месяца', 6: '6 месяцев', 12: '12 месяцев' },
  days:   { 1: 30, 3: 90, 6: 180, 12: 360 }
};

const refParam = new URLSearchParams(location.search).get('ref') || '';
const S = {
  dev: 3, months: 6, promo: '', promoType: null, promoPct: 0,
  refPct: refParam.startsWith('ref_') ? 10 : 0,
  renDev: 6, renMonths: 6, emailBound: true, bindOnly: false,
  subMode: 'main',
  osMain: detectedOs, appMain: 'happ',
  osAwg: (detectedOs === 'appletv' || detectedOs === 'androidtv') ? 'windows' : detectedOs, appAwg: 'amneziavpn',
  osOf: (detectedOs === 'androidtv' || detectedOs === 'appletv') ? 'ios' : detectedOs,
  ofState: 'active', ofCountry: 'nl', ofTargetCountry: 'pl',
  awgTargetSlot: 1
};

if (S.refPct > 0 && $('#refBanner')) $('#refBanner').hidden = false;
if ($('#refClear')) {
  $('#refClear').addEventListener('click', () => {
    S.refPct = 0;
    if ($('#refBanner')) $('#refBanner').hidden = true;
    renderCatalog();
    toast('Реферальная скидка сброшена');
  });
}

/* Плавный анимированный счётчик цифр */
const numReg = new WeakMap();
function num(el, target, suffix = '', dur = 380) {
  if (!el) return;
  let r = numReg.get(el);
  if (!r) {
    const parsed = parseFloat(String(el.textContent).replace(/[^\d.-]/g, ''));
    const initial = !isNaN(parsed) ? parsed : target;
    r = { v: initial, raf: 0 };
    numReg.set(el, r);
  }
  cancelAnimationFrame(r.raf);
  const from = r.v;
  if (Math.round(from) === Math.round(target)) {
    r.v = target;
    el.textContent = fmt(target) + suffix;
    return;
  }
  const t0 = performance.now();
  const step = now => {
    const k = Math.min(1, (now - t0) / dur);
    const e = 1 - Math.pow(1 - k, 4);
    r.v = from + (target - from) * e;
    el.textContent = fmt(r.v) + suffix;
    if (k < 1) r.raf = requestAnimationFrame(step);
  };
  r.raf = requestAnimationFrame(step);
}

function calc(dev, m) {
  const base = CFG.prices[dev][1] * m;
  const cat  = CFG.prices[dev][m];
  const extra = Math.max(S.promoPct, S.refPct);
  const total = S.promoType === 'gift' ? 0 : Math.floor(cat * (100 - extra) / 100);
  return {
    base,
    total,
    per: Math.round(total / m),
    saved: Math.max(base - total, 0),
    pct: base ? Math.round((1 - total / base) * 100) : 0,
    catPct: Math.round((1 - cat / base) * 100)
  };
}

/* Генерация плиток сроков в #tiles */
const tilesEl = $('#tiles');
if (tilesEl) {
  tilesEl.innerHTML = '';
  [1, 3, 6, 12].forEach(m => {
    const b = document.createElement('button');
    b.type = 'button';
    b.className = 'tile';
    b.setAttribute('role', 'radio');
    b.dataset.m = String(m);
    b.innerHTML = `
      <div class="tile-top"><span class="tile-name">${CFG.label[m]}</span><span class="save" hidden></span></div>
      <div class="tile-price"><b class="tab t-per">0</b><span>₽/мес</span></div>
      <div class="tile-total"><b class="tab t-tot">0</b> ₽ всего</div>`;
    b.addEventListener('click', () => {
      S.months = m;
      renderCatalog();
    });
    tilesEl.appendChild(b);
  });
}

/* Универсальная пружинная физика перетаскивания для Liquid Glass Segmented Control */
function bindLiquidSegmented(segEl, getIndexFn, onSelectIdxFn) {
  if (!segEl) return () => {};
  const btns = $$('.seg-btn', segEl);
  let squashTimer = null;
  let down = null;

  function setVisual(index, squash = true) {
    segEl.style.setProperty('--i', index);
    btns.forEach((b, k) => b.setAttribute('aria-checked', String(k === index)));
    if (squash) {
      segEl.classList.add('squash');
      clearTimeout(squashTimer);
      squashTimer = setTimeout(() => segEl.classList.remove('squash'), 220);
    }
  }

  const slotW = () => (segEl.clientWidth - 10) / 3;

  segEl.addEventListener('pointerdown', e => {
    if (e.button !== 0 && e.pointerType === 'mouse') return;
    down = { x: e.clientX, i: getIndexFn(), moved: false, id: e.pointerId, dx: 0 };
    segEl.classList.add('lift');
  });

  segEl.addEventListener('pointermove', e => {
    if (!down) return;
    const dx = e.clientX - down.x;
    if (!down.moved && Math.abs(dx) > 5) {
      down.moved = true;
      segEl.classList.add('drag');
      if (segEl.setPointerCapture) {
        try { segEl.setPointerCapture(down.id); } catch (_) {}
      }
    }
    if (!down.moved) return;
    const base = down.i * slotW();
    const target = Math.min(Math.max(base + dx, 0), 2 * slotW());
    down.dx = target - base;
    segEl.style.setProperty('--dx', down.dx + 'px');
  });

  const endDrag = e => {
    if (!down) return;
    const d = down;
    down = null;
    segEl.classList.remove('lift', 'drag');
    let idx = d.i;
    if (d.moved) {
      idx = Math.round((d.i * slotW() + d.dx) / slotW());
    } else if (e && e.target && e.target.closest) {
      const b = e.target.closest('.seg-btn');
      if (b) idx = btns.indexOf(b);
    }
    idx = Math.min(2, Math.max(0, idx));
    segEl.style.setProperty('--dx', '0px');
    onSelectIdxFn(idx);
  };

  segEl.addEventListener('pointerup', endDrag);
  segEl.addEventListener('pointercancel', () => {
    down = null;
    segEl.classList.remove('lift', 'drag');
    segEl.style.setProperty('--dx', '0px');
  });

  btns.forEach((b, k) => b.addEventListener('click', () => onSelectIdxFn(k)));
  return setVisual;
}

const DEVS = [3, 6, 9];
const setDevSeg = bindLiquidSegmented(
  $('#devSeg'),
  () => DEVS.indexOf(S.dev),
  idx => {
    const next = DEVS[idx];
    const changed = next !== S.dev;
    S.dev = next;
    setDevSeg(idx, changed);
    renderCatalog();
  }
);

/* Отрисовка витрины и понятной зоны финальной цены */
function renderCatalog() {
  const plan = CFG.names[S.dev];
  const cur = calc(S.dev, S.months);
  const devIdx = DEVS.indexOf(S.dev);
  setDevSeg(devIdx >= 0 ? devIdx : 0, false);

  if (tilesEl) {
    $$('.tile', tilesEl).forEach(t => {
      const m = Number(t.dataset.m);
      const c = calc(S.dev, m);
      t.setAttribute('aria-checked', String(m === S.months));
      num($('.t-per', t), c.per);
      num($('.t-tot', t), c.total);
      const sv = $('.save', t);
      if (sv) {
        if (c.catPct > 0) { sv.hidden = false; sv.textContent = `−${c.catPct}%`; }
        else { sv.hidden = true; }
      }
    });
  }

  num($('#awgQ'), CFG.awg[S.dev], ' ГБ');

  const coPlan = $('#coPlan');
  if (coPlan) coPlan.textContent = `Тариф «${plan}» · ${CFG.full[S.months]}`;

  const coPctBadge = $('#coPctBadge');
  if (coPctBadge) {
    coPctBadge.hidden = cur.pct <= 0;
    coPctBadge.textContent = S.promoType === 'gift' ? 'ПОДАРОК −100%' : `−${cur.pct}%`;
  }

  num($('#coPrice'), cur.total);

  const coOld = $('#coOld');
  if (coOld) {
    coOld.textContent = cur.saved > 0 ? `${fmt(cur.base)} ₽` : '';
    coOld.hidden = cur.saved <= 0;
  }

  const coMonthVal = $('#coMonthVal') || $('#coMonth');
  if (coMonthVal) {
    if (S.promoType === 'gift') {
      coMonthVal.textContent = '0';
    } else {
      num(coMonthVal, cur.per, '', 320);
    }
  }

  const coSaveRow = $('#coSaveRow');
  const coSave = $('#coSave');
  const coSavePrefix = $('#coSavePrefix');
  const coSaveVal = $('#coSaveVal');
  const coSaveSuffix = $('#coSaveSuffix');
  if (coSaveRow && coSave) {
    if (S.promoType === 'gift') {
      coSaveRow.hidden = false;
      if (coSavePrefix) coSavePrefix.textContent = 'бесплатно по коду (';
      if (coSaveVal) num(coSaveVal, cur.base, '', 320);
      if (coSaveSuffix) coSaveSuffix.textContent = ' ₽)';
    } else if (S.promoPct > 0) {
      coSaveRow.hidden = false;
      if (coSavePrefix) coSavePrefix.textContent = 'экономия ';
      if (coSaveVal) num(coSaveVal, cur.saved, '', 320);
      if (coSaveSuffix) coSaveSuffix.textContent = ` ₽ (промокод −${S.promoPct}%)`;
    } else if (S.refPct > 0) {
      coSaveRow.hidden = false;
      if (coSavePrefix) coSavePrefix.textContent = 'экономия ';
      if (coSaveVal) num(coSaveVal, cur.saved, '', 320);
      if (coSaveSuffix) coSaveSuffix.textContent = ` ₽ (приглашение −${S.refPct}%)`;
    } else if (cur.saved > 0) {
      coSaveRow.hidden = false;
      if (coSavePrefix) coSavePrefix.textContent = 'экономия ';
      if (coSaveVal) num(coSaveVal, cur.saved, '', 320);
      if (coSaveSuffix) coSaveSuffix.textContent = ' ₽';
    } else {
      coSaveRow.hidden = true;
    }
  }

  const fOffer = $('#fOffer');
  if (fOffer) fOffer.value = `tcp_${S.dev}_${CFG.days[S.months]}`;

  const mbPlan = $('#mbPlan');
  if (mbPlan) mbPlan.textContent = `${plan} · ${CFG.label[S.months]}`;
  const mbPrice = $('#mbPrice');
  if (mbPrice) mbPrice.textContent = `${fmt(cur.total)} ₽`;
}
window.renderCatalog = renderCatalog;

/* Промокоды с плавной аккордеон-анимацией */
const promoToggle = $('#promoToggle');
const promoBoxWrap = $('#promoBoxWrap');
const promoCaret = $('#promoCaret');
if (promoToggle && promoBoxWrap) {
  promoToggle.addEventListener('click', () => {
    const isOpen = promoBoxWrap.classList.contains('open');
    promoBoxWrap.classList.toggle('open', !isOpen);
    promoToggle.setAttribute('aria-expanded', String(!isOpen));
    if (promoCaret) promoCaret.style.transform = !isOpen ? 'rotate(180deg)' : '';
    if (!isOpen) {
      const pInput = $('#promo');
      if (pInput) setTimeout(() => pInput.focus(), 160);
    }
  });
}

const promoInput = $('#promo');
const promoApplyBtn = $('#promoApply');
const promoMsg = $('#promoMsg');

function applyPromo() {
  if (!promoInput) return;
  const code = promoInput.value.trim().toUpperCase();
  if (!code) {
    S.promo = ''; S.promoPct = 0; S.promoType = null;
    if (promoMsg) { promoMsg.className = 'promo-msg'; promoMsg.textContent = 'Примеры для теста: WELCOME10, SALE20 или подарочный GIFT30.'; }
    renderCatalog();
    return;
  }
  if (code === 'WELCOME10' || code === 'TEST10') {
    S.promo = code; S.promoPct = 10; S.promoType = 'pct';
    if (promoMsg) { promoMsg.className = 'promo-msg ok'; promoMsg.textContent = `✓ Промокод ${code} применён (−10%)`; }
    toast(`Промокод ${code} применён!`);
  } else if (code === 'SALE20' || code === 'START') {
    S.promo = code; S.promoPct = 20; S.promoType = 'pct';
    if (promoMsg) { promoMsg.className = 'promo-msg ok'; promoMsg.textContent = `✓ Промокод ${code} применён (−20%)`; }
    toast(`Промокод ${code} применён!`);
  } else if (code === 'GIFT30' || code === 'FREE') {
    S.promo = code; S.promoPct = 100; S.promoType = 'gift';
    if (promoMsg) { promoMsg.className = 'promo-msg ok'; promoMsg.textContent = '✓ Подарочный сертификат активирован (100% скидка)'; }
    toast('Подарочный сертификат применён!');
  } else {
    S.promo = ''; S.promoPct = 0; S.promoType = null;
    if (promoMsg) { promoMsg.className = 'promo-msg err'; promoMsg.textContent = '✕ Промокод не найден или устарел'; }
    toast('Промокод не найден');
  }
  renderCatalog();
}
if (promoApplyBtn) promoApplyBtn.addEventListener('click', applyPromo);
if (promoInput) promoInput.addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); applyPromo(); } });

renderCatalog();

/* =========================================================================
   3. FAQ (Заполнение и интерактивный аккордеон)
   ========================================================================= */
const FAQ_DATA = [
  {
    q: 'Как подключиться за 2 минуты (3 простых шага)?',
    a: '<b>1. Оформите тариф:</b> выберите количество устройств и срок — персональная ссылка появится сразу после подтверждения оплаты.<br><br><b>2. Откройте мастер настройки:</b> ссылка автоматически определит ваше устройство и предложит проверенное приложение в один клик под вашу операционную систему (iOS, Android, Windows или macOS).<br><br><b>3. Нажмите «Подключить»:</b> профиль импортируется в один клик. Перенастраивать вручную ничего не потребуется.'
  },
  {
    q: 'Сохраняется ли история посещений и сетевые логи?',
    a: 'Нет. Мы придерживаемся строгой политики <b>No-Logs</b>. На серверах полностью отключена запись истории посещаемых сайтов (access-логи), DNS-запросов и сетевых маршрутов. Временные системные журналы автоматически очищаются. Для работы подписки хранится только привязанный Email, дата окончания тарифа и счётчик израсходованного объёма.'
  },
  {
    q: 'Действительно ли трафик и скорость безлимитны?',
    a: 'В <b>Основном профиле</b> гигабайты и скорость не ограничиваются — действует прозрачная политика добросовестного использования (Fair Use) для комфортного личного и семейного применения (4K-видео, стриминг, веб-серфинг, игры, загрузка файлов). Для выделенного игрового контура <b>AmneziaWG</b> (прямой UDP с минимальным пингом) предоставляется ежемесячный пакет скоростного трафика: <b>250 ГБ</b> (Личный), <b>500 ГБ</b> (Домашний) или <b>1 000 ГБ</b> (Расширенный).'
  },
  {
    q: 'Будет ли доступ к зарубежным сайтам, нейросетям и медиаплатформам?',
    a: 'Да. Сервис использует современные защищённые протоколы с интеллектуальной маршрутизацией через европейские узлы связи. Все популярные веб-ресурсы, зарубежные сайты, платформы искусственного интеллекта и сетевые сервисы открываются на максимальной скорости вашего интернет-канала.'
  },
  {
    q: 'На каких устройствах работает SilentConnect?',
    a: 'На любых: смартфонах и планшетах <b>iOS</b> (iPhone, iPad) и <b>Android</b>, компьютерах <b>Windows</b>, <b>macOS</b> и <b>Linux</b>, а также на <b>Android TV</b> и <b>Apple TV</b>. Мастер настройки сам подскажет оптимальное приложение под вашу операционную систему.'
  },
  {
    q: 'Зачем указывать Email при заказе?',
    a: 'На почту мы отправляем персональную ссылку доступа, чеки об оплате и напоминания до окончания срока подписки (без спама). По этой почте вы в любой момент сможете войти в личный кабинет с нового устройства и восстановить доступ.'
  },
  {
    q: 'Сколько устройств можно подключить одновременно?',
    a: 'В зависимости от тарифа — <b>3, 6 или 9 устройств</b> одновременно (смартфоны, ноутбуки, планшеты, ТВ). Каждое устройство подключается по своей ссылке или выделенному слоту конфигурации и работает независимо без конфликтов сессий.'
  },
  {
    q: 'Сохранится ли доступ при смене или сбросе телефона?',
    a: 'Да. Ваша ссылка подписки постоянная. При покупке нового устройства или сбросе настроек достаточно снова открыть ссылку из письма на почте или войти в личный кабинет на сайте по Email — все оплаченные дни сохранятся, повторно платить не нужно.'
  },
  {
    q: 'Нужно ли перенастраивать устройства при продлении?',
    a: 'Нет. При продлении тарифа новые дни автоматически суммируются с вашим текущим остатком. Ссылка и конфигурации на всех ваших смартфонах и компьютерах продолжают работать без каких-либо повторных настроек.'
  },
  {
    q: 'Что такое режим «Белые списки»?',
    a: 'В вашу подписку уже включён режим <b>«Белые списки» (OpenFlux)</b>. Он разработан для ситуаций, когда сеть работает в ограниченном режиме и пропускает трафик только по доверенным адресам. Соединение направляется через резервные защищённые шлюзы с выходом в Европе, позволяя оставаться на связи даже при изолированной или нестабильной сети.'
  },
  {
    q: 'Как работает гарантия возврата средств в течение 14 дней?',
    a: 'Для новых пользователей действует 100% гарантия возврата на первый заказ в течение <b>14 календарных дней</b> с момента оплаты (при расходе до 5 ГБ трафика в рамках Fair Use). Если на вашем провайдере сервис не подошёл и поддержка не смогла решить вопрос, напишите в @SilentConnectSupport — мы оформим возврат тем же способом (СБП или карта).'
  }
];

const faqListEl = $('#faqList');
if (faqListEl) {
  faqListEl.innerHTML = FAQ_DATA.map((item, idx) => `
    <div class="faq" data-open="${idx === 0 ? 'true' : 'false'}">
      <button type="button" class="faq-q" aria-expanded="${idx === 0 ? 'true' : 'false'}">
        <span>${item.q}</span>
        <i aria-hidden="true">+</i>
      </button>
      <div class="faq-a"><div><p>${item.a}</p></div></div>
    </div>
  `).join('');

  faqListEl.addEventListener('click', e => {
    const btn = e.target.closest('.faq-q');
    if (!btn) return;
    const faq = btn.closest('.faq');
    if (!faq) return;
    const isOpen = faq.getAttribute('data-open') === 'true';
    const currentOpen = faqListEl.querySelector('.faq[data-open="true"]');
    if (currentOpen && currentOpen !== faq) {
      currentOpen.setAttribute('data-open', 'false');
      const q = $('.faq-q', currentOpen);
      if (q) q.setAttribute('aria-expanded', 'false');
    }
    if (isOpen) {
      faq.setAttribute('data-open', 'false');
      btn.setAttribute('aria-expanded', 'false');
    } else {
      faq.setAttribute('data-open', 'true');
      btn.setAttribute('aria-expanded', 'true');
    }
  });
}

/* =========================================================================
   4. РОУТИНГ СТРАНИЦ / ЭКРАНОВ И СТРАНИЦА ЗАКАЗА
   ========================================================================= */
const TG_SVG = `<svg viewBox="0 0 24 24" width="15" height="15" fill="currentColor" aria-hidden="true" style="flex-shrink:0"><path d="m20.665 3.717-17.73 6.837c-1.21.486-1.203 1.161-.222 1.462l4.552 1.42 10.532-6.645c.498-.303.953-.14.579.192l-8.533 7.701h-.002l-.313 4.674c.458 0 .66-.21.916-.458l2.198-2.137 4.572 3.377c.843.465 1.45.226 1.66-.782l3-14.126c.307-1.232-.469-1.789-1.277-1.421z"/></svg>`;
const TG_SUPPORT_URL = 'https://t.me/SilentConnectSupport';
const TG_BOT_SVG = `<svg viewBox="0 0 24 24" width="15" height="15" fill="currentColor" aria-hidden="true" style="flex-shrink:0"><path fill-rule="evenodd" clip-rule="evenodd" d="M12 2.5C7.8 2.5 6 5.5 6 9.5V17c0 2.5 1.8 4.5 4.5 4.5h3c2.7 0 4.5-2 4.5-4.5V9.5C18 5.5 16.2 2.5 12 2.5zM8.4 10.8V9.5C8.4 7.2 9.8 5.2 12 5.2s3.6 2 3.6 4.3v1.3H8.4zM3.5 8.5C4.33 8.5 5 9.17 5 10v6c0 .83-.67 1.5-1.5 1.5S2 16.83 2 16v-6c0-.83.67-1.5 1.5-1.5zm17 0c.83 0 1.5.67 1.5 1.5v6c0 .83-.67 1.5-1.5 1.5s-1.5-.67-1.5-1.5v-6c0-.83.67-1.5 1.5-1.5z"/></svg>`;

function updateNavForView(name) {
  const navLinks = $('#navLinks') || $('.nav-links');
  const navActions = $('#navActions') || $('.nav-actions');
  if (!navLinks || !navActions) return;

  if (name === 'landing') {
    navLinks.innerHTML = `
      <a href="#tariffs" data-go="landing">Тарифы</a>
      <a href="#features" data-go="landing">Возможности</a>
      <a href="#faq" data-go="landing">Вопросы</a>
    `;
    navActions.innerHTML = `
      <button type="button" class="btn btn-ghost btn-sm" data-open-cabinet>Кабинет</button>
    `;
  } else if (name === 'sub') {
    navLinks.innerHTML = `
      <a href="#renewAcc" data-nav-action="renew">Продлить</a>
      <a href="#modeBar" data-nav-action="scroll">Режимы</a>
      <a href="#subViewport" data-nav-action="scroll">Инструкция</a>
    `;
    navActions.innerHTML = `
      <a class="btn btn-telegram btn-sm" href="${TG_SUPPORT_URL}" target="_blank" rel="noopener">${TG_SVG}<span>Поддержка</span></a>
      <button type="button" class="btn btn-ghost btn-sm hide-sm" data-open-cabinet>Кабинет</button>
    `;
  } else if (name === 'order') {
    navLinks.innerHTML = `
      <a href="#top" data-go="landing">← На главную</a>
    `;
    navActions.innerHTML = `
      <a class="btn btn-telegram btn-sm" href="${TG_SUPPORT_URL}" target="_blank" rel="noopener">${TG_SVG}<span>Поддержка</span></a>
    `;
  } else if (name === 'cabinet') {
    navLinks.innerHTML = `
      <a href="#top" data-nav-action="scroll">Мои подписки</a>
      <a href="#tariffs" data-go="landing">Оформить новую</a>
      <a href="#view-legal" data-go="legal">Документы</a>
    `;
    navActions.innerHTML = `
      <a class="btn btn-telegram btn-sm" href="${TG_SUPPORT_URL}" target="_blank" rel="noopener">${TG_SVG}<span>Поддержка</span></a>
    `;
  } else if (name === 'legal') {
    navLinks.innerHTML = `
      <a href="#top" data-go="landing">← На главную</a>
      <a href="#tariffs" data-go="landing">Тарифы</a>
    `;
    navActions.innerHTML = `
      <a class="btn btn-telegram btn-sm hide-sm" href="${TG_SUPPORT_URL}" target="_blank" rel="noopener">${TG_SVG}<span>Поддержка</span></a>
      <button type="button" class="btn btn-ghost btn-sm" data-open-cabinet>Кабинет</button>
    `;
  }
}

const VIEWS = ['landing', 'order', 'sub', 'cabinet', 'legal'];
function view(name, hash) {
  if (!VIEWS.includes(name)) name = 'landing';
  VIEWS.forEach(v => {
    const el = $('#view-' + v);
    if (el) el.hidden = v !== name;
  });
  $$('[data-page-tab]').forEach(b => b.classList.toggle('on', b.dataset.pageTab === name));
  if (mbarEl) mbarEl.style.display = name === 'landing' ? '' : 'none';

  updateNavForView(name);

  const target = hash && hash.length > 1 ? $(hash) : null;
  if (target) setTimeout(() => target.scrollIntoView({ behavior: 'smooth' }), 30);
  else window.scrollTo({ top: 0, behavior: 'auto' });
  syncNavScroll();
}
window.view = view;

$$('[data-page-tab]').forEach(b => b.addEventListener('click', () => view(b.dataset.pageTab)));
document.addEventListener('click', e => {
  const a = e.target.closest('[data-go]');
  if (!a) return;
  const href = a.getAttribute('href') || '';
  if (a.dataset.go === 'landing' && !$('#view-landing').hidden && href.startsWith('#')) {
    return;
  }
  e.preventDefault();
  closeAllModals();
  const doc = a.dataset.docLink;
  if (doc) showLegalDoc(doc);
  view(a.dataset.go, href.startsWith('#') ? href : '');
});

document.addEventListener('click', e => {
  const a = e.target.closest('[data-nav-action]');
  if (!a) return;
  e.preventDefault();
  const action = a.dataset.navAction;
  const href = a.getAttribute('href') || '';

  if (action === 'renew') {
    const doOpenRenew = () => {
      const el = $('#renewAcc');
      if (el) {
        if (typeof setRenewOpen === 'function') setRenewOpen(true);
        else if (window.setRenewOpen) window.setRenewOpen(true);
        else el.setAttribute('data-open', 'true');
        const headerOffset = 76;
        const elPos = el.getBoundingClientRect().top;
        const offsetPos = elPos + window.pageYOffset - headerOffset;
        window.scrollTo({ top: offsetPos, behavior: 'smooth' });
      }
    };
    if ($('#view-sub') && $('#view-sub').hidden) {
      view('sub');
      setTimeout(doOpenRenew, 60);
    } else {
      doOpenRenew();
    }
  } else if (action === 'scroll' && href && href.startsWith('#')) {
    if (href === '#top') {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    } else {
      const target = $(href);
      if (target) {
        const headerOffset = 76;
        const elPos = target.getBoundingClientRect().top;
        const offsetPos = elPos + window.pageYOffset - headerOffset;
        window.scrollTo({ top: offsetPos, behavior: 'smooth' });
      }
    }
  }
});

document.addEventListener('click', e => {
  const btn = e.target.closest('[data-open-cabinet]');
  if (!btn) return;
  e.preventDefault();
  openModal('cabinetModal');
});


function setOrderState(state) {
  if (!['waiting', 'delivered', 'cancelled'].includes(state)) state = 'waiting';
  if ($('#ordWait')) $('#ordWait').hidden = state !== 'waiting';
  if ($('#ordDone')) $('#ordDone').hidden = state !== 'delivered';
  if ($('#ordCancelled')) $('#ordCancelled').hidden = state !== 'cancelled';

  $$('[data-order-state]').forEach(b => b.classList.toggle('on', b.dataset.orderState === state));

  const badge = $('#ordBadge');
  if (badge) {
    if (state === 'waiting') { badge.className = 'status wait'; badge.innerHTML = '<i></i>Ожидает оплаты'; }
    else if (state === 'delivered') { badge.className = 'status ok'; badge.innerHTML = '<i></i>Оплачен'; }
    else { badge.className = 'status cancel'; badge.innerHTML = '<i></i>Отменён'; }
  }
}

$$('[data-order-state]').forEach(b => {
  b.addEventListener('click', () => {
    setOrderState(b.dataset.orderState);
    if (b.dataset.orderState === 'delivered') toast('✓ Оплата успешно подтверждена!');
  });
});

if ($('#payBtn')) {
  $('#payBtn').addEventListener('click', e => {
    e.preventDefault();
    toast('Подтверждение оплаты…');
    setTimeout(() => {
      setOrderState('delivered');
      toast('✓ Подписка активирована!');
    }, 450);
  });
}
if ($('#cancelOrdBtn')) {
  $('#cancelOrdBtn').addEventListener('click', () => {
    setOrderState('cancelled');
    toast('Заказ отменён');
  });
}

const orderForm = $('#orderForm');
if (orderForm) {
  orderForm.addEventListener('submit', e => {
    e.preventDefault();
    const emailField = $('#email');
    const email = (emailField ? emailField.value : '').trim();
    if (!email || !email.includes('@')) {
      if (emailField) emailField.classList.add('err');
      const err = $('#emailErr');
      if (err) err.hidden = false;
      toast('Укажите корректный Email для получения ключа');
      return;
    }
    const cur = calc(S.dev, S.months);
    if ($('#ordPlanName')) $('#ordPlanName').textContent = `${CFG.names[S.dev]} · до ${S.dev} устройств`;
    if ($('#ordDuration')) $('#ordDuration').textContent = `${CFG.days[S.months]} дней (${CFG.full[S.months]})`;
    if ($('#ordAwg')) $('#ordAwg').textContent = `${CFG.awg[S.dev]} ГБ в месяц`;
    if ($('#ordEmail')) $('#ordEmail').textContent = email;
    if ($('#ordTotal')) $('#ordTotal').textContent = `${fmt(cur.total)} ₽`;
    if ($('#payBtnSum')) $('#payBtnSum').textContent = `${fmt(cur.total)} ₽`;

    toast('Создание защищённого заказа…');
    setTimeout(() => {
      setOrderState(cur.total === 0 ? 'delivered' : 'waiting');
      view('order');
    }, 300);
  });
}
const emailInputEl = $('#email');
if (emailInputEl) {
  emailInputEl.addEventListener('input', () => {
    emailInputEl.classList.remove('err');
    const err = $('#emailErr');
    if (err) err.hidden = true;
  });
}

/* =========================================================================
   5. МАСТЕР ПОДКЛЮЧЕНИЯ: ОСНОВНОЙ РЕЖИМ (subjson-service/app.py)
   ========================================================================= */
const U = {
  HAPP_DOWNLOAD: 'https://www.happ.su/main',
  HAPP_IOS: 'https://apps.apple.com/us/app/happ-proxy-utility/id6504287215',
  HAPP_ANDROID: 'https://play.google.com/store/apps/details?id=com.happproxy',
  HAPP_APK: 'https://github.com/Happ-proxy/happ-android/releases/latest/download/Happ.apk',
  STREISAND_IOS: 'https://apps.apple.com/us/app/streisand/id6450534064',
  STREISAND_MACOS: 'https://apps.apple.com/us/app/streisand/id6450534064',
  CLASH_MI_IOS: 'https://apps.apple.com/app/clash-mi/id6744321968',
  CLASH_DL: 'https://github.com/clash-verge-rev/clash-verge-rev/releases',
  CLASH_ANDROID: 'https://github.com/MetaCubeX/ClashMetaForAndroid/releases',
  V2RAYN_DL: 'https://github.com/2dust/v2rayN/releases',
  NEKOBOX_DL: 'https://github.com/MatsuriDayo/NekoBoxForAndroid/releases',
  V2RAYNG_DL: 'https://github.com/2dust/v2rayNG/releases',
  SINGBOX_IOS: 'https://apps.apple.com/app/sing-box-mt/id6785326793',
  SINGBOX_DL: 'https://github.com/SagerNet/sing-box/releases'
};
const dl = (label, url, icon) => ({ label, url, icon });

const MAIN_APPS = [
  { id: 'happ', name: 'Happ', badge: 'рекомендуем', icon: 'assets/apps/happ.webp',
    platforms: ['ios', 'android', 'windows', 'macos', 'linux', 'androidtv', 'appletv'],
    description: 'Флагманский клиент с поддержкой протоколов REALITY и XHTTP. Обеспечивает максимальную скорость и незаметность подключения на любых устройствах.',
    downloads: {
      ios: [dl('App Store', U.HAPP_IOS, 'appstore')],
      android: [dl('Google Play', U.HAPP_ANDROID, 'googleplay'), dl('GitHub Релизы (.apk)', U.HAPP_APK, 'github')],
      windows: [dl('Официальный сайт (.exe)', U.HAPP_DOWNLOAD, 'globe')],
      macos: [dl('Официальный сайт (.dmg)', U.HAPP_DOWNLOAD, 'globe')],
      linux: [dl('Официальный сайт (.deb / AppImage)', U.HAPP_DOWNLOAD, 'globe')],
      androidtv: [dl('Google Play', U.HAPP_ANDROID, 'googleplay'), dl('GitHub Релизы (.apk)', U.HAPP_APK, 'github')],
      appletv: [dl('App Store', U.HAPP_IOS, 'appstore')]
    } },
  { id: 'clash', name: 'Clash Mi / Mihomo', badge: 'авто-выбор', icon: 'assets/apps/clash.webp', iosIcon: 'assets/apps/clash_mi.webp',
    platforms: ['windows', 'macos', 'android', 'linux', 'ios'],
    description: 'Мощный клиент с поддержкой умного авто-тестирования узлов и мгновенным переключением при сбоях.',
    downloads: {
      windows: [dl('GitHub Релизы (.exe)', U.CLASH_DL, 'github')],
      macos: [dl('GitHub Релизы (.dmg)', U.CLASH_DL, 'github')],
      android: [dl('GitHub Релизы (.apk)', U.CLASH_ANDROID, 'github')],
      linux: [dl('GitHub Релизы (.deb / AppImage)', U.CLASH_DL, 'github')],
      ios: [dl('App Store', U.CLASH_MI_IOS, 'appstore')]
    } },
  { id: 'v2rayn', name: 'v2rayN', badge: 'windows xray', icon: 'assets/apps/v2rayn.webp',
    platforms: ['windows'],
    description: 'Популярный клиент для Windows с поддержкой Xray-ядра, автоматическим обновлением подписок и гибкой маршрутизацией.',
    downloads: { windows: [dl('GitHub Релизы (.zip)', U.V2RAYN_DL, 'github')] } },
  { id: 'nekobox', name: 'NekoBox', badge: 'android json', icon: 'assets/apps/nekobox.webp',
    platforms: ['android'],
    description: 'Мощный и функциональный клиент для Android с поддержкой прямых JSON и Sing-box конфигураций.',
    downloads: { android: [dl('GitHub Релизы (.apk)', U.NEKOBOX_DL, 'github')] } },
  { id: 'v2rayng', name: 'v2rayNG', badge: 'android vless', icon: 'assets/apps/v2rayng.webp',
    platforms: ['android'],
    description: 'Классический проверенный клиент для Android для прямого импорта VLESS-конфигураций.',
    downloads: { android: [dl('GitHub Релизы (.apk)', U.V2RAYNG_DL, 'github')] } },
  { id: 'streisand', name: 'Streisand', badge: 'ios / macos', icon: 'assets/apps/streisand.webp',
    platforms: ['ios', 'macos'],
    description: 'Лёгкий и быстрый клиент, идеально оптимизированный под экосистемы iOS и macOS без расхода аккумулятора.',
    downloads: {
      ios: [dl('App Store', U.STREISAND_IOS, 'appstore')],
      macos: [dl('Mac App Store', U.STREISAND_MACOS, 'appstore')]
    } },
  { id: 'singbox', name: 'Sing-box', badge: 'sing-box', icon: 'assets/apps/singbox.webp',
    platforms: ['ios', 'android', 'windows', 'macos', 'linux'],
    description: 'Универсальный сетевой клиент нового поколения с максимальной производительностью и нативной поддержкой Sing-box JSON.',
    downloads: {
      ios: [dl('App Store', U.SINGBOX_IOS, 'appstore')],
      android: [dl('GitHub Релизы (.apk)', U.SINGBOX_DL, 'github')],
      windows: [dl('GitHub Релизы (.zip)', U.SINGBOX_DL, 'github')],
      macos: [dl('GitHub Релизы (.dmg / .zip)', U.SINGBOX_DL, 'github')],
      linux: [dl('GitHub Релизы (.tar.gz)', U.SINGBOX_DL, 'github')]
    } }
];

function usageText(appId, os) {
  const map = {
    happ: 'Запустите Happ и нажмите большую центральную кнопку включения. При первом запуске разрешите системе добавление сетевого профиля в появившемся запросе.',
    streisand: 'Откройте Streisand, подтвердите добавление профиля SilentConnect и переключите верхний тумблер в активное состояние.',
    clash: os === 'ios'
      ? 'Откройте Clash Mi, импортируйте профиль SilentConnect (кнопка выше сделает это автоматически), выберите профиль и включите тумблер подключения.'
      : 'Откройте Clash / Mihomo, импортируйте профиль SilentConnect, выберите профиль и включите системный прокси (System Proxy) или TUN-режим.',
    v2rayn: 'Откройте v2rayN, вставьте ссылку подписки через «Подписка» → «Настройки подписок», нажмите «Обновить подписки» и выберите узел для подключения.',
    nekobox: 'Откройте NekoBox, обновите подписку через меню и нажмите круглую кнопку запуска внизу экрана.',
    v2rayng: 'Откройте v2rayNG, обновите подписку через верхнее меню и нажмите кнопку подключения с буквой V.',
    singbox: os === 'ios'
      ? 'Откройте sing-box MT, импортируйте профиль SilentConnect и нажмите кнопку включения (Dashboard → Start).'
      : 'Откройте Sing-box, импортируйте профиль SilentConnect и нажмите кнопку включения (Dashboard → Start).'
  };
  return map[appId] || 'Откройте приложение, добавьте подписку SilentConnect и нажмите кнопку подключения.';
}

function badgeClassOf(badge) {
  const b = (badge || '').toLowerCase();
  if (b.includes('ios') || b.includes('macos')) return 'badge-ios';
  if (b.includes('авто')) return 'badge-auto';
  if (b.includes('windows')) return 'badge-windows';
  if (b.includes('android')) return 'badge-android';
  if (b.includes('sing')) return 'badge-singbox';
  return 'badge-recommended';
}

function renderPlatformTrack(track, list, activeId, onPick, suffix) {
  if (!track) return;
  track.innerHTML = '';
  list.forEach(p => {
    const b = document.createElement('button');
    const on = p.id === activeId;
    b.type = 'button';
    b.className = 'platform-tab' + (on ? ' active' : '');
    b.setAttribute('role', 'tab');
    b.setAttribute('aria-selected', String(on));
    b.innerHTML = p.svg.replace(/finder-(blue|silver)/g, 'finder-$1-' + suffix) + `<span>${p.label}</span>`;
    b.addEventListener('click', () => {
      onPick(p.id);
      centerActiveTab(track);
    });
    track.appendChild(b);
  });
  setupDraggableTrack(track);
  centerActiveTab(track);
}

function dlButtonsHtml(items) {
  return (items || []).map(d => `
    <a href="${d.url}" target="_blank" rel="noopener" class="btn btn-ghost btn-sm">
      ${d.icon === 'globe' ? '<span class="btn-globe" aria-hidden="true"><svg class="ico" viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="10"/><line x1="2" y1="12" x2="22" y2="12"/><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/></svg></span>' : `<img src="assets/stores/${d.icon}.webp" alt="" class="btn-store-icon" onerror="this.style.display='none'">`}
      <span>${d.label}</span>
    </a>`).join('');
}

function preferredMainApp(os) {
  const cur = MAIN_APPS.find(a => a.id === S.appMain);
  if (cur && cur.platforms.includes(os)) return cur.id;
  const happ = MAIN_APPS.find(a => a.id === 'happ' && a.platforms.includes(os));
  if (happ) return 'happ';
  const first = MAIN_APPS.find(a => a.platforms.includes(os));
  return first ? first.id : 'happ';
}

function renderMainSetup() {
  renderPlatformTrack($('#osTabsMain'), OS_META, S.osMain, id => {
    S.osMain = id;
    S.appMain = preferredMainApp(id);
    renderMainSetup();
  }, 'main');

  S.appMain = preferredMainApp(S.osMain);
  const os = S.osMain;
  const curOsEl = $('#curOsNameMain');
  if (curOsEl) curOsEl.textContent = OS_LABEL[os] || os;

  const avail = MAIN_APPS.filter(a => a.platforms.includes(os));
  const cur = avail.find(a => a.id === S.appMain) || avail[0];

  const grid = $('#appsGridMain');
  if (grid) {
    grid.innerHTML = '';
    avail.forEach(a => {
      let name = a.name, icon = a.icon;
      if (os === 'ios') {
        if (a.id === 'singbox') name = 'sing-box MT';
        else if (a.id === 'clash') { name = 'Clash Mi'; if (a.iosIcon) icon = a.iosIcon; }
      }
      const on = a.id === cur.id;
      const card = document.createElement('button');
      card.type = 'button';
      card.className = 'app-card' + (on ? ' active' : '');
      card.innerHTML = `
        <img src="${icon}" alt="${name}" class="app-icon-img" onerror="this.style.display='none'">
        <div class="app-info"><div class="app-name-row">
          <span class="app-name">${name}</span>
          <span class="app-badge ${badgeClassOf(a.badge)}">${a.badge}</span>
        </div></div>
        <span class="app-check" aria-hidden="true">${on ? '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>' : ''}</span>`;
      card.addEventListener('click', () => {
        S.appMain = a.id;
        renderMainSetup();
      });
      grid.appendChild(card);
    });
  }

  const title = cur.id === 'singbox' && os === 'ios' ? 'sing-box MT' : (cur.id === 'clash' && os === 'ios' ? 'Clash Mi' : cur.name);
  const stepsGrid = $('#stepsGridMain');
  if (stepsGrid) {
    stepsGrid.innerHTML = `
      <div class="s-step">
        <div>
          <div class="s-step-head"><span class="s-step-num">1</span><h4>Установка клиента</h4></div>
          <p>${cur.description} Операционная система: ${OS_LABEL[os]}.</p>
        </div>
        <div class="step-btns">${dlButtonsHtml(cur.downloads[os] || [])}</div>
      </div>
      <div class="s-step">
        <div>
          <div class="s-step-head"><span class="s-step-num">2</span><h4>Автоматический импорт ключа</h4></div>
          <p>Нажмите «Добавить подписку». Приложение откроется автоматически и применит зашифрованный профиль SilentConnect.</p>
        </div>
        <div class="step-btns"><a href="${importUrlFor(cur.id)}" class="btn btn-primary btn-sm" onclick="event.preventDefault();toast('Открываем ${title} и передаём профиль…')">Добавить подписку <svg class="ico" viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/></svg></a></div>
      </div>
      <div class="s-step done">
        <div>
          <div class="s-step-head"><span class="s-step-num">3</span><h4>Активация соединения</h4></div>
          <p>${usageText(cur.id, os)}</p>
        </div>
      </div>
      <div class="s-step">
        <div>
          <div class="s-step-head"><span class="s-step-num">4</span><h4>Резервный способ (ручной импорт)</h4></div>
          <p>Если бесшовный переход не сработал: скопируйте ссылку ниже в буфер обмена и выберите «Импорт из буфера обмена» в настройках приложения.</p>
        </div>
        <div class="step-btns"><button type="button" class="btn btn-ghost btn-sm" onclick="copyToClipboard('${SUB_IMPORT_URL}', 'Ссылка подписки скопирована!')">Скопировать ссылку <svg class="ico" viewBox="0 0 24 24" width="13" height="13" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"/><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"/></svg></button></div>
        <input class="field mono-field" readonly value="${SUB_IMPORT_URL}" aria-label="Ссылка подписки" onclick="this.select()">
      </div>`;
  }
}
renderMainSetup();

/* =========================================================================
   6. ПЕРЕКЛЮЧАТЕЛЬ 3 РЕЖИМОВ ПОДКЛЮЧЕНИЯ (Liquid Glass с физикой перетаскивания)
   ========================================================================= */
const MODES = ['main', 'awg', 'openflux'];
const setModeSegVisual = bindLiquidSegmented(
  $('#modeSeg'),
  () => MODES.indexOf(S.subMode),
  idx => {
    const mode = MODES[idx] || 'main';
    setSubMode(mode);
  }
);

function setSubMode(mode) {
  if (!MODES.includes(mode)) mode = 'main';
  const newIdx = MODES.indexOf(mode);
  const changed = mode !== S.subMode;
  S.subMode = mode;
  setModeSegVisual(newIdx, changed);

  // Horizontal slide translation (0%, -33.3333%, -66.6666%)
  const slider = $('#subModeSlider');
  if (slider) {
    slider.style.transform = `translateX(-${newIdx * 33.333333}%)`;
  }

  if (mode === 'main') renderMainSetup();
  else if (mode === 'awg') renderAwgSetup();
  else if (mode === 'openflux') renderOfSetup();
  syncSubViewport();
}
window.setSubMode = setSubMode;

/* Высота окна карусели = высота активной панели (плавно, следит за изменением контента) */
function syncSubViewport() {
  const viewport = $('#subViewport');
  const pane = $(`#pane-${S.subMode}`);
  if (!viewport || !pane) return;
  const h = pane.offsetHeight;
  if (h > 0) viewport.style.height = h + 'px';
  MODES.forEach(m => {
    const p = $(`#pane-${m}`);
    if (!p) return;
    p.inert = m !== S.subMode;
    p.setAttribute('aria-hidden', String(m !== S.subMode));
  });
}
if (window.ResizeObserver) {
  const subRO = new ResizeObserver(syncSubViewport);
  MODES.forEach(m => { const p = $(`#pane-${m}`); if (p) subRO.observe(p); });
}
syncSubViewport();

/* =========================================================================
   Bento «Что вы получаете»: на узких экранах ПК-раскладка целиком уменьшается
   ========================================================================= */
(function fitBentoInit() {
  const wrap = $('.bento-scaler-wrap');
  const bento = wrap && wrap.querySelector('.bento');
  if (!wrap || !bento) return;
  const DESIGN_W = 720;
  function fitBento() {
    const w = wrap.clientWidth;
    if (!w) return;
    if (w < DESIGN_W) {
      const k = w / DESIGN_W;
      bento.classList.add('is-scaled');
      bento.style.transform = `scale(${k})`;
      wrap.style.height = Math.ceil(bento.offsetHeight * k) + 'px';
    } else {
      bento.classList.remove('is-scaled');
      bento.style.transform = '';
      wrap.style.height = '';
    }
  }
  if (window.ResizeObserver) new ResizeObserver(fitBento).observe(wrap.parentElement);
  window.addEventListener('resize', fitBento);
  fitBento();
})();

/* =========================================================================
   7. РЕЖИМ 2: AMNEZIAWG (vpn_shop/web.py render_awg_slots_widget)
   ========================================================================= */
const AWG_OS_LIST = OS_META.filter(o => ['ios', 'android', 'windows', 'macos', 'linux'].includes(o.id));
const AWG_APPS = [
  { id: 'amneziavpn', name: 'AmneziaVPN', badge: 'официальный', icon: 'assets/apps/amneziavpn.webp',
    platforms: ['ios', 'android', 'windows', 'macos', 'linux'],
    description: 'Официальный полнофункциональный клиент с автоматической поддержкой профилей AmneziaWG и встроенной защитой от DPI.',
    downloads: {
      ios: [dl('App Store', 'https://apps.apple.com/app/amneziavpn/id1600529900', 'appstore')],
      android: [dl('Google Play', 'https://play.google.com/store/apps/details?id=org.amnezia.vpn', 'googleplay'), dl('GitHub Релизы (.apk)', 'https://github.com/amnezia-vpn/amnezia-client/releases', 'github')],
      windows: [dl('GitHub Релизы (.exe)', 'https://github.com/amnezia-vpn/amnezia-client/releases', 'github')],
      macos: [dl('GitHub Релизы (.dmg)', 'https://github.com/amnezia-vpn/amnezia-client/releases', 'github')],
      linux: [dl('GitHub Релизы (.deb / AppImage)', 'https://github.com/amnezia-vpn/amnezia-client/releases', 'github')]
    } },
  { id: 'amneziawg', name: 'AmneziaWG Client', badge: 'легкий wireguard', icon: 'assets/apps/amneziawg.webp',
    platforms: ['windows', 'android', 'macos', 'ios'],
    description: 'Специализированная облегчённая сборка на базе нативного клиента WireGuard с поддержкой заголовков обфускации Jc/Jmin/Jmax.',
    downloads: {
      ios: [dl('App Store', 'https://apps.apple.com/app/amneziawg/id6478942364', 'appstore')],
      android: [dl('Google Play', 'https://play.google.com/store/apps/details?id=org.amnezia.awg', 'googleplay')],
      windows: [dl('GitHub Релизы (.msi)', 'https://github.com/amnezia-vpn/amneziawg-windows-client/releases', 'github')],
      macos: [dl('App Store', 'https://apps.apple.com/app/amneziawg/id6478942364', 'appstore')]
    } }
];

const AWG_SERVERS = {
  nl: { code: 'nl', name: 'Нидерланды', city: 'Амстердам', flag: '<span class="flag-badge" aria-label="Нидерланды"><svg width="16" height="11" viewBox="0 0 16 11" fill="none" aria-hidden="true"><rect width="16" height="11" rx="2" fill="#fff"/><rect width="16" height="3.67" rx="2" fill="#AE1C28"/><rect y="7.33" width="16" height="3.67" rx="2" fill="#21468B"/><rect y="2" width="16" height="7" fill="#fff"/></svg></span>', ping: 32 },
  pl: { code: 'pl', name: 'Польша', city: 'Варшава', flag: '<span class="flag-badge" aria-label="Польша"><svg width="16" height="11" viewBox="0 0 16 11" fill="none" aria-hidden="true"><rect width="16" height="11" rx="2" fill="#DC143C"/><rect width="16" height="5.5" rx="2" fill="#fff"/></svg></span>', ping: 24 },
  fi: { code: 'fi', name: 'Финляндия', city: 'Хельсинки', flag: '<span class="flag-badge" aria-label="Финляндия"><svg width="16" height="11" viewBox="0 0 16 11" fill="none" aria-hidden="true"><rect width="16" height="11" rx="2" fill="#fff"/><rect x="4.5" width="3" height="11" fill="#002F6C"/><rect y="4" width="16" height="3" fill="#002F6C"/></svg></span>', ping: 19 }
};

const AWG_SLOTS = [
  { id: 1, name: 'Рабочий MacBook', server: 'nl', ip: '10.8.0.2', active: true },
  { id: 2, name: 'iPhone 16 Pro', server: 'pl', ip: '10.8.0.3', active: true },
  { id: 3, name: 'Домашний роутер', server: 'fi', ip: '10.8.0.4', active: false }
];

function mockAwgConfig(slot) {
  return `[Interface]
PrivateKey = aB8f...DEMO_KEY...=
Address = ${slot.ip}/32
DNS = 1.1.1.1, 8.8.8.8
Jc = 4
Jmin = 40
Jmax = 70
S1 = 15
S2 = 30
H1 = 1
H2 = 2
H3 = 3
H4 = 4

[Peer]
PublicKey = xT9q...SERVER_PUB_KEY...=
Endpoint = ${slot.server}.edge.silentconnect.net:38421
AllowedIPs = 0.0.0.0/0
PersistentKeepalive = 25`;
}

function renderAwgSetup() {
  renderPlatformTrack($('#osTabsAwg'), AWG_OS_LIST, S.osAwg, id => {
    S.osAwg = id;
    renderAwgSetup();
  }, 'awg');

  const curOsEl = $('#curOsNameAwg');
  if (curOsEl) curOsEl.textContent = OS_LABEL[S.osAwg] || S.osAwg;

  const slotsCont = $('#awgSlotsGrid');
  if (slotsCont) {
    slotsCont.innerHTML = '';
    AWG_SLOTS.forEach(slot => {
      const srv = AWG_SERVERS[slot.server] || AWG_SERVERS.nl;
      const card = document.createElement('div');
      card.className = 'slot';
      card.innerHTML = `
        <div>
          <div class="slot-top">
            <span style="font-weight:700;color:#fff;font-size:14.5px;display:inline-flex;align-items:center;gap:6px">
              <span><svg class="ico" viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="5" y="2" width="14" height="20" rx="2" ry="2"/><line x1="12" y1="18" x2="12.01" y2="18"/></svg></span> <span id="slotNameText-${slot.id}">${slot.name}</span>
              <button type="button" style="font-size:12px;opacity:.75;cursor:pointer" title="Переименовать" onclick="promptRenameSlot(${slot.id})"><svg class="ico" viewBox="0 0 24 24" width="12" height="12" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg></button>
            </span>
            <span class="status ${slot.active ? 'ok' : 'wait'}"><i></i>${slot.active ? 'Активен' : 'Свободен'}</span>
          </div>
          <div style="margin-top:10px;font-size:13px;color:var(--mut);display:flex;justify-content:space-between">
            <span>Шлюз: <b style="color:#fff">${srv.flag} ${srv.name}</b></span>
            <span>IP: <code style="color:var(--em-t)">${slot.ip}</code></span>
          </div>
        </div>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:10px">
          <button type="button" class="btn btn-primary btn-sm" onclick="downloadSlotConf(${slot.id})"><svg class="ico" viewBox="0 0 24 24" width="13" height="13" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg> .conf</button>
          <button type="button" class="btn btn-ghost btn-sm" onclick="openSlotQrModal(${slot.id})"><svg class="ico" viewBox="0 0 24 24" width="13" height="13" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/></svg> QR-код</button>
          <button type="button" class="btn btn-ghost btn-sm" onclick="copySlotConf(${slot.id})"><svg class="ico" viewBox="0 0 24 24" width="13" height="13" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg> Ключ</button>
          <button type="button" class="btn btn-ghost btn-sm" onclick="openAwgSwitchModal(${slot.id})"><svg class="ico" viewBox="0 0 24 24" width="13" height="13" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21.5 2v6h-6M21.34 15.57a10 10 0 1 1-.57-8.38l5.67-1.19"/></svg> Сервер</button>
        </div>`;
      slotsCont.appendChild(card);
    });
  }

  const grid = $('#appsGridAwg');
  if (grid) {
    grid.innerHTML = '';
    const avail = AWG_APPS.filter(a => a.platforms.includes(S.osAwg));
    const cur = avail.find(a => a.id === S.appAwg) || avail[0];
    avail.forEach(a => {
      const on = a.id === cur.id;
      const card = document.createElement('button');
      card.type = 'button';
      card.className = 'app-card' + (on ? ' active' : '');
      card.innerHTML = `
        <img src="${a.icon}" alt="${a.name}" class="app-icon-img" onerror="this.style.display='none'">
        <div class="app-info"><div class="app-name-row">
          <span class="app-name">${a.name}</span>
          <span class="app-badge ${badgeClassOf(a.badge)}">${a.badge}</span>
        </div></div>
        <span class="app-check" aria-hidden="true">${on ? '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>' : ''}</span>`;
      card.addEventListener('click', () => { S.appAwg = a.id; renderAwgSetup(); });
      grid.appendChild(card);
    });

    const stepsGrid = $('#stepsGridAwg');
    if (stepsGrid) {
      stepsGrid.innerHTML = `
        <div class="s-step">
          <div>
            <div class="s-step-head"><span class="s-step-num">1</span><h4>Установка клиента Amnezia VPN</h4></div>
            <p>Скачайте официальное бесплатное приложение с открытым исходным кодом для вашей операционной системы (${OS_LABEL[S.osAwg]}):</p>
          </div>
          <div class="step-btns">${dlButtonsHtml(cur.downloads[S.osAwg] || [])}</div>
        </div>
        <div class="s-step">
          <div>
            <div class="s-step-head"><span class="s-step-num">2</span><h4>Добавление конфигурации устройства</h4></div>
            <p>Выберите нужный слот в блоке выше (например, «Устройство 1» для смартфона, «Устройство 2» для ПК):</p>
            <ul style="margin:6px 0 0 18px;padding:0;font-size:13px;color:var(--dim);line-height:1.5">
              <li><b>На смартфоне:</b> Нажмите «🔲 QR-код» у слота, в Amnezia VPN нажмите <b>«+»</b> → <b>«Сканировать QR-код»</b>.</li>
              <li><b>На компьютере:</b> Нажмите «📥 .conf», в Amnezia VPN выберите <b>«Файл с настройками»</b> и укажите скачанный файл.</li>
            </ul>
          </div>
          <div class="step-btns"><button type="button" class="btn btn-primary btn-sm" onclick="downloadSlotConf(1)"><svg class="ico" viewBox="0 0 24 24" width="13" height="13" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg> Скачать слот #1 (.conf)</button></div>
        </div>
        <div class="s-step done">
          <div>
            <div class="s-step-head"><span class="s-step-num">3</span><h4>Подключение и работа</h4></div>
            <p>Нажмите центральную кнопку подключения в Amnezia VPN. Весь заблокированный трафик пойдёт через наш скоростной шифрованный WireGuard-канал без потери скорости.</p>
          </div>
        </div>`;
    }
  }
}

window.downloadSlotConf = function(slotId) {
  const slot = AWG_SLOTS.find(s => s.id === slotId) || AWG_SLOTS[0];
  const conf = mockAwgConfig(slot);
  const blob = new Blob([conf], { type: 'text/plain;charset=utf-8' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = `silentconnect-slot-${slot.id}.conf`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  toast(`Файл silentconnect-slot-${slot.id}.conf скачан!`);
};

window.copySlotConf = function(slotId) {
  const slot = AWG_SLOTS.find(s => s.id === slotId) || AWG_SLOTS[0];
  copyToClipboard(mockAwgConfig(slot), `Конфигурация слота #${slot.id} скопирована!`);
};

window.openSlotQrModal = function(slotId) {
  const slot = AWG_SLOTS.find(s => s.id === slotId) || AWG_SLOTS[0];
  openQrModal(`QR-код: ${slot.name}`, mockAwgConfig(slot));
};

window.promptRenameSlot = function(slotId) {
  const slot = AWG_SLOTS.find(s => s.id === slotId);
  if (!slot) return;
  const newName = window.prompt('Введите новое название для устройства:', slot.name);
  if (newName && newName.trim()) {
    slot.name = newName.trim();
    renderAwgSetup();
    toast(`Устройство переименовано в «${slot.name}»`);
  }
};

window.openAwgSwitchModal = function(slotId) {
  S.awgTargetSlot = slotId || 1;
  const slot = AWG_SLOTS.find(s => s.id === S.awgTargetSlot) || AWG_SLOTS[0];
  const title = $('#awgModalSlotTitle');
  if (title) title.textContent = `#${slot.id} (${slot.name})`;
  const radio = $(`input[name="awg_country"][value="${slot.server}"]`);
  if (radio) radio.checked = true;
  openModal('awgSwitchModal');
};

const awgApplyBtn = $('#awgConfirmSwitchBtn');
if (awgApplyBtn) {
  awgApplyBtn.addEventListener('click', () => {
    const checked = $('input[name="awg_country"]:checked');
    if (checked) {
      const code = checked.value;
      const slot = AWG_SLOTS.find(s => s.id === S.awgTargetSlot);
      if (slot) {
        slot.server = code;
        renderAwgSetup();
        const srv = AWG_SERVERS[code];
        toast(`Слот переключён на ${srv.name}! Скачайте новый .conf`);
      }
    }
    closeAllModals();
  });
}

const pingBtn = $('#pingBtn');
if (pingBtn) {
  pingBtn.addEventListener('click', () => {
    toast('Измеряем сетевую задержку до узлов Европы…');
    ['pNl', 'pPl', 'pFi'].forEach(id => {
      const el = $('#' + id);
      if (el) el.textContent = '…';
    });
    setTimeout(() => {
      const pNl = $('#pNl'); if (pNl) pNl.textContent = (28 + Math.floor(Math.random() * 8)) + ' мс';
      const pPl = $('#pPl'); if (pPl) pPl.textContent = (22 + Math.floor(Math.random() * 6)) + ' мс';
      const pFi = $('#pFi'); if (pFi) pFi.textContent = (18 + Math.floor(Math.random() * 5)) + ' мс';
      toast('✓ Задержка обновлена');
    }, 420);
  });
}

/* =========================================================================
   8. РЕЖИМ 3: OPENFLUX (subjson-service/app.py whitelist-mode-container)
   ========================================================================= */
const OF_OS_LIST = OS_META.filter(o => ['ios', 'android', 'windows', 'macos', 'linux'].includes(o.id));
let ofTimerInterval = null;
let ofTimeRemaining = 288;

function setOfState(state) {
  S.ofState = state;
  const inact = $('#ofInactive');
  const act = $('#ofActive');
  const mig = $('#ofMigrating');
  if (inact) inact.hidden = state !== 'inactive';
  if (act) act.hidden = state !== 'active';
  if (mig) mig.hidden = state !== 'migrating';

  $$('[data-of-state]').forEach(b => b.classList.toggle('on', b.dataset.ofState === state));

  const srv = AWG_SERVERS[S.ofCountry] || AWG_SERVERS.nl;
  const targetSrv = AWG_SERVERS[S.ofTargetCountry] || AWG_SERVERS.pl;

  const actCountryEl = $('#ofActiveCountry');
  if (actCountryEl) actCountryEl.innerHTML = `${srv.flag} ${srv.name} (${srv.city})`;

  const targetCountryEl = $('#ofTargetCountry');
  if (targetCountryEl) targetCountryEl.innerHTML = `${targetSrv.flag} ${targetSrv.name} (${targetSrv.city})`;

  const keyInput = $('#ofKeyInput');
  if (keyInput) keyInput.value = `openflux://v1/${SUB_ID}-${srv.code}?doc=mailru_shared_doc_88f29&srv=${srv.code}.edge.silentconnect.net:443#SilentConnect-OpenFlux-${srv.code.toUpperCase()}`;

  const newKeyInput = $('#ofNewKeyInput');
  if (newKeyInput) newKeyInput.value = `openflux://v1/mig_${SUB_ID}-${targetSrv.code}?doc=mailru_shared_doc_88f29&srv=${targetSrv.code}.edge.silentconnect.net:443#SilentConnect-OpenFlux-${targetSrv.code.toUpperCase()}`;

  if (state === 'migrating') startOfHandoverTimer();
  else clearInterval(ofTimerInterval);
}
window.setOfState = setOfState;

function startOfHandoverTimer() {
  clearInterval(ofTimerInterval);
  const timerBox = $('#ofTimer');
  function tick() {
    if (ofTimeRemaining <= 0) {
      clearInterval(ofTimerInterval);
      S.ofCountry = S.ofTargetCountry;
      setOfState('active');
      toast('Миграция автоматически завершена!');
      return;
    }
    const m = Math.floor(ofTimeRemaining / 60);
    const s = ofTimeRemaining % 60;
    if (timerBox) timerBox.textContent = `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
    ofTimeRemaining--;
  }
  tick();
  ofTimerInterval = setInterval(tick, 1000);
}

const OF_CLIENT_DATA = {
  ios: {
    name: 'OpenFlux для iOS',
    downloads: [
      dl('1. Присоединиться в TestFlight', 'https://testflight.apple.com/join/BwnAcdus', 'testflight'),
      dl('TestFlight в App Store', 'https://apps.apple.com/app/testflight/id899247664', 'appstore')
    ],
    step1: 'Присоединитесь к официальному бета-тестированию OpenFlux для iOS через Apple TestFlight по кнопкам ниже.',
    step2: 'Нажмите «Скопировать ключ» выше, откройте OpenFlux на iPhone и нажмите «Вставить из буфера» (или отсканируйте «🔲 QR-код»).',
    step3: 'В приложении OpenFlux нажмите синюю кнопку «Start VPN» ⚡. При первом запуске подтвердите добавление VPN-конфигурации в диалоговом окне iOS.'
  },
  android: {
    name: 'OpenFlux для Android',
    downloads: [
      dl('GitHub Релизы (.apk)', 'https://github.com/p1neappleXpress/OpenFluxAndroid/releases/latest', 'github')
    ],
    step1: 'Скачайте официальный APK-файл OpenFlux с GitHub Releases и установите его (разрешите установку из браузера при запросе).',
    step2: 'Нажмите кнопку «1-Click импорт» или отсканируйте QR-код активного слота выше — браузер передаст профиль в OpenFlux.',
    step3: 'Нажмите большую центральную кнопку «Tap to connect» и разрешите системный запрос Android на подключение VPN.'
  },
  windows: {
    name: 'OpenFlux Desktop для Windows',
    downloads: [
      dl('GitHub Релизы (.exe / .zip)', 'https://github.com/p1neappleXpress/OpenFluxDesktop/releases/latest', 'github')
    ],
    step1: 'Скачайте официальный дистрибутив OpenFlux Desktop (.msi / .exe или портативный .zip) для Windows 10/11 (64-bit).',
    step2: 'Нажмите «Скопировать ключ», откройте OpenFlux Desktop и выберите «Профили» → «Импорт» (Ctrl+I). Включите режим «Весь трафик» (Wintun).',
    step3: 'В приложении OpenFlux Desktop нажмите кнопку включения туннеля для защиты всего интернет-трафика ПК.'
  },
  macos: {
    name: 'OpenFlux для macOS',
    downloads: [
      dl('Присоединиться в TestFlight', 'https://testflight.apple.com/join/BwnAcdus', 'testflight'),
      dl('GitHub Релизы (.dmg)', 'https://github.com/p1neappleXpress/OpenFluxDesktop/releases/latest', 'github')
    ],
    step1: 'Установите OpenFlux через TestFlight или скачайте готовый бинарный пакет (.dmg) с GitHub Releases для Apple Silicon / Intel.',
    step2: 'Скопируйте ключ слота выше и добавьте его в настройки OpenFlux.',
    step3: 'Включите туннель в OpenFlux для защищённой работы в условиях ограничений сети.'
  },
  linux: {
    name: 'OpenFlux для Linux',
    downloads: [
      dl('GitHub Релизы (.deb / .tar.gz)', 'https://github.com/p1neappleXpress/OpenFluxDesktop/releases/latest', 'github')
    ],
    step1: 'Скачайте официальный пакет OpenFlux (.deb / AppImage / CLI) с GitHub Releases.',
    step2: 'Импортируйте строку openflux:// в конфигурационный файл или GUI.',
    step3: 'Активируйте VPN-интерфейс tun0.'
  }
};

function renderOfSetup() {
  renderPlatformTrack($('#osTabsOf'), OF_OS_LIST, S.osOf, id => {
    S.osOf = id;
    renderOfSetup();
  }, 'of');

  const curOsEl = $('#curOsNameOf');
  if (curOsEl) curOsEl.textContent = OS_LABEL[S.osOf] || S.osOf;

  const data = OF_CLIENT_DATA[S.osOf] || OF_CLIENT_DATA.ios;
  const stepsGrid = $('#stepsGridOf');
  if (stepsGrid) {
    stepsGrid.innerHTML = `
      <div class="s-step">
        <div>
          <div class="s-step-head"><span class="s-step-num">1</span><h4>Установка ${data.name}</h4></div>
          <p>${data.step1}</p>
        </div>
        <div class="step-btns">${dlButtonsHtml(data.downloads)}</div>
      </div>
      <div class="s-step">
        <div>
          <div class="s-step-head"><span class="s-step-num">2</span><h4>Добавление подключения</h4></div>
          <p>${data.step2}</p>
        </div>
        <div class="step-btns">
          <button type="button" class="btn btn-primary btn-sm" onclick="copyToClipboard($('#ofKeyInput')?.value || '', 'Ключ OpenFlux скопирован!')"><svg class="ico" viewBox="0 0 24 24" width="13" height="13" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg> Скопировать ключ OpenFlux</button>
          <button type="button" class="btn btn-ghost btn-sm" onclick="openQrModal('OpenFlux QR-код', $('#ofKeyInput')?.value || '')"><svg class="ico" viewBox="0 0 24 24" width="13" height="13" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/></svg> QR-код</button>
        </div>
      </div>
      <div class="s-step done">
        <div>
          <div class="s-step-head"><span class="s-step-num">3</span><h4>Активация соединения</h4></div>
          <p>${data.step3}</p>
        </div>
      </div>`;
  }
}

$$('[data-of-state]').forEach(b => b.addEventListener('click', () => setOfState(b.dataset.ofState)));
$$('[data-set-of]').forEach(b => b.addEventListener('click', () => setOfState(b.dataset.setOf)));

$$('[data-open-wl-picker]').forEach(b => {
  b.addEventListener('click', () => {
    const mode = b.dataset.openWlPicker;
    const title = $('#wlPickerTitle');
    if (title) {
      title.innerHTML = mode === 'activate'
        ? '<svg class="ico" viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="10"/><line x1="2" y1="12" x2="22" y2="12"/><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/></svg> Выберите страну для активации OpenFlux'
        : '<svg class="ico" viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="10"/><line x1="2" y1="12" x2="22" y2="12"/><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/></svg> Смена локации OpenFlux (с безопасным окном миграции)';
    }
    openModal('wlPickerModal');
  });
});

const wlConfirmPickBtn = $('#wlConfirmPickBtn');
if (wlConfirmPickBtn) {
  wlConfirmPickBtn.addEventListener('click', () => {
    const checked = $('input[name="wl_country"]:checked');
    const targetCode = checked ? checked.value : 'pl';
    closeAllModals();

    if (S.ofState === 'inactive') {
      S.ofCountry = targetCode;
      setOfState('active');
      toast(`✓ Слот OpenFlux активирован на ${AWG_SERVERS[targetCode].name}!`);
    } else {
      S.ofTargetCountry = targetCode;
      ofTimeRemaining = 300;
      setOfState('migrating');
      toast(`Подготовлен новый сервер: ${AWG_SERVERS[targetCode].name}. Скопируйте новый ключ!`);
    }
  });
}

const ofConfirmBtn = $('#ofConfirmBtn');
if (ofConfirmBtn) ofConfirmBtn.addEventListener('click', () => openModal('ofConfirmModal'));

const ofFinalizeBtn = $('#ofFinalizeBtn');
if (ofFinalizeBtn) {
  ofFinalizeBtn.addEventListener('click', () => {
    S.ofCountry = S.ofTargetCountry;
    closeAllModals();
    setOfState('active');
    toast('✓ Переход на новый сервер успешно завершён! Старый сервер отключён.');
  });
}

setOfState('active');

/* =========================================================================
   9. АККОРДЕОН ПРОДЛЕНИЯ И ПРИВЯЗКИ ПОЧТЫ
   ========================================================================= */
const renewAcc = $('#renewAcc');
const renewToggle = $('#renewToggle');
const bindEmailOnlyChk = $('#bindEmailOnly');

function setRenewOpen(open) {
  window.setRenewOpen = setRenewOpen;
  if (!renewAcc) return;
  renewAcc.setAttribute('data-open', String(open));
  if (renewToggle) renewToggle.setAttribute('aria-expanded', String(open));
}

if (renewToggle) {
  renewToggle.addEventListener('click', () => {
    const isOpen = renewAcc.getAttribute('data-open') === 'true';
    setRenewOpen(!isOpen);
  });
}

function syncRenewEmailState() {
  if (!renewAcc) return;
  $$('[data-email-state]').forEach(b => {
    b.classList.toggle('on', (b.dataset.emailState === 'bound') === S.emailBound);
  });
  const subBoundEmail = $('#subBoundEmail');
  if (!S.emailBound) {
    setRenewOpen(true);
    renewAcc.classList.add('warn-unbound');
    if (subBoundEmail) { subBoundEmail.textContent = 'не привязана'; subBoundEmail.style.color = 'var(--warn)'; }
    const badge = $('#renewEmailBadge');
    if (badge) { badge.className = 'status wait'; badge.innerHTML = '<i></i>Почта не привязана'; }
    if ($('#emailUnboundAlert')) $('#emailUnboundAlert').hidden = false;
    if ($('#emailBoundPill')) $('#emailBoundPill').hidden = true;
  } else {
    renewAcc.classList.remove('warn-unbound');
    if (subBoundEmail) { subBoundEmail.textContent = 'c***t@example.com'; subBoundEmail.style.color = 'var(--em-t)'; }
    const badge = $('#renewEmailBadge');
    if (badge) { badge.className = 'status ok'; badge.innerHTML = '<i></i>Почта привязана'; }
    if ($('#emailUnboundAlert')) $('#emailUnboundAlert').hidden = true;
    if ($('#emailBoundPill')) $('#emailBoundPill').hidden = false;
  }
}

$$('[data-email-state]').forEach(b => {
  b.addEventListener('click', () => {
    S.emailBound = b.dataset.emailState === 'bound';
    syncRenewEmailState();
  });
});

function renderRenewCalculations() {
  $$('[data-r-dev]').forEach(b => b.classList.toggle('active', Number(b.dataset.rDev) === S.renDev));
  $$('[data-r-m]').forEach(b => b.classList.toggle('active', Number(b.dataset.rM) === S.renMonths));

  const price = CFG.prices[S.renDev][S.renMonths];
  const totalEl = $('#renPrice');
  const sumEl = $('#renSummary');
  const submitBtn = $('#renSubmitBtn');
  const selectors = $('#renewPlanSelectors');
  const bindCard = $('#bindOnlyCard');

  if (S.bindOnly) {
    if (sumEl) sumEl.textContent = 'Привязка / смена почты без оплаты';
    if (totalEl) totalEl.textContent = '0 ₽';
    if (submitBtn) submitBtn.innerHTML = 'Привязать почту <svg class="btn-arrow" viewBox="0 0 16 16" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4"/></svg>';
    if (selectors) selectors.classList.add('dimmed-block');
    if (bindCard) bindCard.classList.add('active');
  } else {
    if (sumEl) sumEl.textContent = `${CFG.names[S.renDev]} (${S.renDev} устр.) · +${CFG.days[S.renMonths]} дней`;
    if (totalEl) num(totalEl, price, ' ₽', 280);
    if (submitBtn) submitBtn.innerHTML = `Оплатить ${fmt(price)} ₽ <svg class="btn-arrow" viewBox="0 0 16 16" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4"/></svg>`;
    if (selectors) selectors.classList.remove('dimmed-block');
    if (bindCard) bindCard.classList.remove('active');
  }
}

$$('[data-r-dev]').forEach(b => {
  b.addEventListener('click', () => {
    S.renDev = Number(b.dataset.rDev);
    renderRenewCalculations();
  });
});
$$('[data-r-m]').forEach(b => {
  b.addEventListener('click', () => {
    S.renMonths = Number(b.dataset.rM);
    renderRenewCalculations();
  });
});

if (bindEmailOnlyChk) {
  bindEmailOnlyChk.addEventListener('change', e => {
    S.bindOnly = e.target.checked;
    renderRenewCalculations();
  });
}

const renForm = $('#renewForm');
if (renForm) {
  renForm.addEventListener('submit', e => {
    e.preventDefault();
    const mailInput = $('#renewEmailInput');
    const mail = (mailInput ? mailInput.value : '').trim();
    if (!mail || !mail.includes('@')) {
      toast('Укажите корректный адрес электронной почты');
      if (mailInput) mailInput.focus();
      return;
    }
    if (S.bindOnly) {
      S.emailBound = true;
      S.bindOnly = false;
      if (bindEmailOnlyChk) bindEmailOnlyChk.checked = false;
      syncRenewEmailState();
      renderRenewCalculations();
      toast(`✓ Почта ${mail} успешно привязана к подписке!`);
      const boundLbl = $('#boundEmailLabel');
      if (boundLbl) boundLbl.textContent = mail;
    } else {
      toast('Создание счёта на продление…');
      setTimeout(() => {
        setOrderState('waiting');
        view('order');
      }, 300);
    }
  });
}

const changeBoundEmailBtn = $('#changeBoundEmailBtn');
if (changeBoundEmailBtn) {
  changeBoundEmailBtn.addEventListener('click', () => {
    if (bindEmailOnlyChk) {
      bindEmailOnlyChk.checked = true;
      S.bindOnly = true;
      renderRenewCalculations();
    }
    const mailInput = $('#renewEmailInput');
    if (mailInput) {
      mailInput.value = '';
      mailInput.focus();
    }
  });
}

syncRenewEmailState();
renderRenewCalculations();

/* =========================================================================
   10. МОДАЛЬНЫЕ ОКНА И COMMAND PALETTE (⌘K)
   ========================================================================= */
function openModal(modalId) {
  const m = $('#' + modalId);
  if (!m) return;
  m.classList.add('open');
  m.removeAttribute('hidden');
}
window.openModal = openModal;

function closeAllModals() {
  $$('.modal').forEach(m => {
    m.classList.remove('open');
    m.setAttribute('hidden', '');
  });
}
window.closeAllModals = closeAllModals;

$$('[data-close]').forEach(b => b.addEventListener('click', closeAllModals));
$$('.modal').forEach(m => m.addEventListener('click', e => { if (e.target === m) closeAllModals(); }));

function openQrModal(title, text) {
  const titleEl = $('#qrTitle');
  if (titleEl) titleEl.textContent = title;
  const subEl = $('#qrSub');
  if (subEl) subEl.textContent = text;
  const qrBox = $('#qrModal .qr');
  if (qrBox) renderSvgQr(text, qrBox, 164);
  openModal('qrModal');
}
window.openQrModal = openQrModal;

$$('[data-qr]').forEach(b => {
  b.addEventListener('click', () => openQrModal(b.dataset.qr || 'QR-код', SUB_IMPORT_URL));
});

$$('[data-open-cabinet]').forEach(b => {
  b.addEventListener('click', () => openModal('cabinetModal'));
});

const cabinetForm = $('#cabinetForm');
if (cabinetForm) {
  cabinetForm.addEventListener('submit', e => {
    e.preventDefault();
    closeAllModals();
    toast('Вход в личный кабинет выполнен!');
    view('cabinet');
  });
}

/* Command Palette (⌘K / Ctrl+K) */
const CMD_LIST = [
  { label: 'Выбрать тариф и оформить подписку', hint: 'Витрина (/)', act: () => view('landing', '#tariffs') },
  { label: 'Мастер настройки: Основной профиль', hint: '/sub/setup/…', act: () => { setSubMode('main'); view('sub'); } },
  { label: 'Мастер настройки: Игровой AmneziaWG', hint: '/sub/setup/…', act: () => { setSubMode('awg'); view('sub'); } },
  { label: 'Мастер настройки: Белые списки (OpenFlux)', hint: '/sub/setup/…', act: () => { setSubMode('openflux'); view('sub'); } },
  { label: 'Страница заказа и статуса оплаты', hint: '/order/…', act: () => view('order') },
  { label: 'Личный кабинет подписок', hint: '/cabinet/…', act: () => view('cabinet') },
  { label: 'Политика возвратов (Гарантия 14 дней)', hint: 'Документы', act: () => { showLegalDoc('refund'); view('legal'); } },
  { label: 'Политика конфиденциальности (No-Logs)', hint: 'Документы', act: () => { showLegalDoc('privacy'); view('legal'); } },
  { label: 'Контакты и поддержка 24/7', hint: 'Документы', act: () => { showLegalDoc('contact'); view('legal'); } }
];

function renderCmdPalette(q = '') {
  const box = $('#cmdList');
  if (!box) return;
  const query = q.trim().toLowerCase();
  const items = CMD_LIST.filter(i => !query || i.label.toLowerCase().includes(query) || i.hint.toLowerCase().includes(query));
  box.innerHTML = '';
  items.forEach(item => {
    const b = document.createElement('button');
    b.type = 'button';
    b.className = 'cmd-item';
    b.innerHTML = `<span>${item.label}</span><small>${item.hint}</small>`;
    b.addEventListener('click', () => { closeAllModals(); item.act(); });
    box.appendChild(b);
  });
}

$$('[data-open-cmd]').forEach(b => {
  b.addEventListener('click', () => {
    renderCmdPalette('');
    openModal('cmdModal');
    const input = $('#cmdInput');
    if (input) { input.value = ''; setTimeout(() => input.focus(), 50); }
  });
});

const cmdInput = $('#cmdInput');
if (cmdInput) cmdInput.addEventListener('input', e => renderCmdPalette(e.target.value));

window.addEventListener('keydown', e => {
  if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') {
    e.preventDefault();
    renderCmdPalette('');
    openModal('cmdModal');
    if (cmdInput) { cmdInput.value = ''; setTimeout(() => cmdInput.focus(), 50); }
  } else if (e.key === 'Escape') {
    closeAllModals();
  }
});

/* =========================================================================
   11. РАЗДЕЛ ЮРИДИЧЕСКОЙ ИНФОРМАЦИИ (Все 5 документов: about, contact, terms, privacy, refund)
   ========================================================================= */
const LEGAL_DOCS = {
  about: {
    title: 'О сервисе SilentConnect',
    date: 'Инфраструктура приватного доступа нового поколения',
    html: `
      <p>Передовой сервис приватного сетевого доступа нового поколения, созданный для безопасного и стабильного интернета.</p>
      
      <h3 style="color:#fff;font-size:18px;margin-top:22px">Наша миссия</h3>
      <p>Мы верим, что свободный и безопасный доступ к информации — это фундаментальное право каждого человека. SilentConnect создавался с нуля для работы в сложных сетевых условиях, где стандартные методы подключения легко распознаются и замедляются провайдерами.</p>

      <h3 style="color:var(--em-t);font-size:18px;margin-top:22px">Инфраструктура и технологии:</h3>
      <ul style="padding-left:20px;line-height:1.8;color:var(--mut)">
        <li><strong style="color:#fff">Современное защищенное шифрование:</strong> Наш трафик маскируется под стандартный защищенный протокол веб-сервисов. Для сетевых фильтров ваше подключение выглядит как обычный визит на веб-сайт.</li>
        <li><strong style="color:#fff">Приватность сетевого доступа:</strong> На серверных узлах отключена фиксация сетевых маршрутов, DNS и истории посещаемых ресурсов. Временные системные журналы серверов автоматически очищаются каждые 48 часов.</li>
        <li><strong style="color:#fff">Европейские гигабитные узлы:</strong> Серверы размещены в современных дата-центрах Нидерландов и Финляндии с прямыми магистральными каналами связи и минимальным пингом.</li>
        <li><strong style="color:#fff">Умная доставка и личный кабинет:</strong> Мгновенная генерация подписки, отправка чеков и ключей на Email, удобное управление через веб-интерфейс и Telegram-бота.</li>
        <li><strong style="color:#fff">Поддержка любых устройств:</strong> Готовые мастера установки под iOS (Happ, Streisand), Android (Happ, V2RayTun), Windows, macOS, Linux, Android TV и Apple TV.</li>
      </ul>

      <p style="margin-top:24px;color:var(--mut)">Техническая поддержка: <a href="mailto:support@silentconnect.net" style="color:var(--em-t);text-decoration:underline">support@silentconnect.net</a></p>`
  },
  contact: {
    title: 'Контакты & Поддержка',
    date: 'Круглосуточная помощь 24/7/365 · Ответ в течение 2–5 минут',
    html: `
      <p>Мы работаем круглосуточно и готовы оперативно помочь с любыми вопросами по настройке и оплате.</p>

      <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:14px;margin:22px 0">
        <div style="background:rgba(255,255,255,0.03);border:1px solid rgba(255,255,255,0.08);border-radius:14px;padding:18px">
          <h3 style="color:var(--em-t);margin-top:0;font-size:17px"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="display:inline-block;vertical-align:-3px;margin-right:6px;color:var(--em-t)"><rect x="2" y="4" width="20" height="16" rx="2"/><path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7"/></svg>Электронная почта</h3>
          <p style="font-size:13.5px;color:var(--mut);margin-bottom:10px">Вопросы по заказам, чекам, возвратам и корпоративным подпискам:</p>
          <a href="mailto:support@silentconnect.net" style="color:#fff;font-weight:600;font-size:15px;text-decoration:underline">support@silentconnect.net</a>
        </div>

        <div style="background:rgba(255,255,255,0.03);border:1px solid rgba(255,255,255,0.08);border-radius:14px;padding:18px">
          <h3 style="color:#38bdf8;margin-top:0;font-size:17px"><svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor" style="display:inline-block;vertical-align:-3px;margin-right:6px;color:#38bdf8"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm4.64 6.8c-.15 1.58-.8 5.42-1.13 7.19-.14.75-.42 1-.68 1.03-.58.05-1.02-.38-1.58-.75-.88-.58-1.38-.94-2.23-1.5-.99-.65-.35-1.01.22-1.59.15-.15 2.71-2.48 2.76-2.69a.2.2 0 00-.05-.18c-.06-.05-.14-.03-.21-.02-.09.02-1.49.95-4.22 2.79-.4.27-.76.41-1.08.4-.36-.01-1.04-.2-1.55-.37-.63-.2-1.12-.31-1.08-.66.02-.18.27-.36.74-.55 2.92-1.27 4.86-2.11 5.83-2.51 2.78-1.16 3.35-1.36 3.73-1.36.08 0 .27.02.39.12.1.08.13.19.14.27-.01.06.01.24 0 .37z"/></svg>Telegram Поддержка</h3>
          <p style="font-size:13.5px;color:var(--mut);margin-bottom:10px">Мгновенная помощь специалиста, проверка статуса ключей и продление доступа:</p>
          <a href="https://t.me/SilentConnectSupport" style="color:#fff;font-weight:600;font-size:15px;text-decoration:underline" target="_blank" rel="noopener">@SilentConnectSupport</a>
        </div>
      </div>

      <h3 style="color:#fff;font-size:17px;margin-top:20px">Режим работы поддержки:</h3>
      <p style="color:var(--mut);line-height:1.7">Консультации и техническая помощь предоставляются круглосуточно (24/7/365). Среднее время ответа в Telegram — 2–5 минут, по электронной почте — до 15–30 минут.</p>`
  },
  terms: {
    title: 'Пользовательское соглашение (Публичная оферта)',
    date: 'Редакция от 5 сентября 2026 г. · ст. 435, 437, 438 ГК РФ',
    html: `
      <p>Настоящее Пользовательское соглашение (далее — «Соглашение» или «Оферта») регулирует отношения между Администрацией сервиса <strong>SilentConnect</strong> (далее — «Исполнитель») и любым физическим или юридическим лицом, использующим сервисы Сайта, Telegram-бота или инфраструктуру Платформы (далее — «Пользователь»).</p>

      <h3 style="color:#fff;font-size:17px;margin-top:22px">1. Термины и определения</h3>
      <ul style="padding-left:20px;line-height:1.8;color:var(--mut)">
        <li><strong style="color:#fff">Сервис (Платформа)</strong> — программно-аппаратный комплекс SilentConnect, предназначенный для защищенного сетевого взаимодействия, криптографической маршрутизации и безопасной передачи данных через интернет.</li>
        <li><strong style="color:#fff">Индивидуальный ключ доступа</strong> — уникальная зашифрованная ссылка (URL подписки) либо конфигурационный файл, генерируемый для аутентификации абонентских устройств Пользователя на узлах Сервиса.</li>
        <li><strong style="color:#fff">Заказ</strong> — действие Пользователя по выбору Тарифа, заполнению контактных данных и оплате услуг через сайт или интерфейс бота.</li>
        <li><strong style="color:#fff">Тариф</strong> — установленный Исполнителем объем прав доступа, определяющий срок подписки и лимит одновременно подключенных устройств (3, 6 или 9 устройств).</li>
      </ul>

      <h3 style="color:#fff;font-size:17px;margin-top:22px">2. Акцепт оферты и заключение договора</h3>
      <p style="color:var(--mut)">2.1. Настоящий документ является публичной офертой в соответствии со статьями 435 и 437 Гражданского кодекса Российской Федерации (ГК РФ).</p>
      <p style="color:var(--mut)">2.2. Полным и безоговорочным акцептом настоящей Оферты (ст. 438 ГК РФ) признается совершение Пользователем любого из следующих конклюдентных действий: нажатие кнопки оформления/оплаты заказа, совершение платежа, авторизация в боте либо фактическое использование сгенерированного индивидуального ключа доступа.</p>
      <p style="color:var(--mut)">2.3. Акцептуя Оферту, Пользователь подтверждает, что достиг совершеннолетия, обладает полной право- и дееспособностью, ознакомился и безоговорочно согласен со всеми положениями настоящего Соглашения, а также с Политикой конфиденциальности и Политикой возвратов.</p>

      <h3 style="color:var(--em-t);font-size:17px;margin-top:22px">3. Предмет соглашения и момент исполнения обязательств</h3>
      <p style="color:var(--mut)">3.1. Исполнитель предоставляет Пользователю неисключительное право использования программного обеспечения и услуги защищенного сетевого взаимодействия для безопасной передачи данных в соответствии с выбранным Тарифом.</p>
      <p style="color:var(--mut)"><strong style="color:#fff">3.2. Момент оказания услуг:</strong> Обязательства Исполнителя по предоставлению доступа считаются исполненными надлежащим образом и в полном объеме в момент автоматической генерации и отображения индивидуального ключа доступа (URL подписки) в веб-интерфейсе либо отправки на указанный Пользователем адрес электронной почты или в Telegram. Фактическая настройка клиентского ПО на стороне абонентского оборудования осуществляется Пользователем самостоятельно.</p>

      <h3 style="color:#fff;font-size:17px;margin-top:22px">4. Стоимость услуг и порядок расчетов</h3>
      <p style="color:var(--mut)">4.1. Стоимость Тарифов публикуется на Сайте и в интерфейсах Сервиса в российских рублях (RUB). Исполнитель вправе в одностороннем порядке изменять стоимость будущих периодов; изменение стоимости уже оплаченного Пользователем периода не допускается.</p>
      <p style="color:var(--mut)">4.2. Оплата производится через сертифицированные платежные шлюзы (включая Систему быстрых платежей СБП / НСПК и банковские карты). Обязательства по оплате считаются исполненными с момента подтверждения зачисления средств банком-эквайером.</p>
      <p style="color:var(--mut)">4.3. Автоматические скрытые списания (рекуррентные подписки без предварительного согласия) сервисом не применяются. Продление осуществляется по добровольной инициативе Пользователя.</p>

      <h3 style="color:#fff;font-size:17px;margin-top:22px">5. Правила добросовестного использования (Fair Use Policy)</h3>
      <p style="color:var(--mut)">5.1. Пользователь обязуется использовать Сервис исключительно в законных целях для личных и семейных нужд в пределах лимита устройств по Тарифу (до 3, 6 или 9 устройств одновременно).</p>
      <p style="color:var(--mut)">5.2. Категорически запрещается использовать Сервис для:</p>
      <ul style="padding-left:20px;line-height:1.8;color:var(--mut)">
        <li>Осуществления массовых спам-рассылок, фишинга, мошеннических действий и социальной инженерии;</li>
        <li>Проведения сетевых атак любого рода (DDoS, брутфорс, несанкционированное сканирование портов и уязвимостей);</li>
        <li>Распространения вредоносного программного обеспечения, эксплойтов и троянских программ;</li>
        <li>Нарушения законодательства РФ и прав интеллектуальной собственности третьих лиц;</li>
        <li>Организации публичных прокси-серверов, майнинга, торрент-ферм и перепродажи доступа третьим лицам.</li>
      </ul>
      <p style="color:var(--mut)">5.3. При выявлении грубых нарушений п. 5.2 Исполнитель оставляет за собой право немедленно приостановить или заблокировать доступ без компенсации и возврата средств.</p>

      <h3 style="color:#fff;font-size:17px;margin-top:22px">6. Ограничение ответственности и отказ от гарантий</h3>
      <p style="color:var(--mut)">6.1. Сервис предоставляется на условиях «КАК ЕСТЬ» («AS IS»). Исполнитель принимает все разумные меры для обеспечения непрерывной и стабильной работы узлов связи, однако не гарантирует абсолютную безошибочность или бесперебойность.</p>
      <p style="color:var(--mut)">6.2. Исполнитель не несет ответственности за временные перебои, вызванные действиями локальных интернет-провайдеров Пользователя, магистральных операторов связи, авариями кабельной инфраструктуры, плановыми техническими работами и сетевыми сбоями сторонних операторов связи либо иными форс-мажорными обстоятельствами вне контроля Исполнителя.</p>
      <p style="color:var(--mut)">6.3. Совокупная ответственность Исполнителя по любым претензиям строго ограничена суммой, фактически уплаченной Пользователем за текущий расчетный период.</p>

      <h3 style="color:#fff;font-size:17px;margin-top:22px">7. Изменение условий и контакты</h3>
      <p style="color:var(--mut)">7.1. Исполнитель вправе в одностороннем порядке вносить изменения в настоящую Оферту. Новая редакция вступает в силу с момента ее публикации на данной странице.</p>
      <p style="color:var(--mut);margin-top:10px">
        Электронная почта: <a href="mailto:support@silentconnect.net" style="color:var(--em-t);text-decoration:underline">support@silentconnect.net</a><br>
        Telegram-бот поддержки: <a href="https://t.me/SilentConnectSupport" style="color:var(--em-t);text-decoration:underline" target="_blank" rel="noopener">@SilentConnectSupport</a>
      </p>`
  },
  privacy: {
    title: 'Политика конфиденциальности SilentConnect',
    date: 'Редакция от 5 сентября 2026 г. · Принципы обработки данных (152-ФЗ / GDPR)',
    html: `
      <p>Сервис <strong>SilentConnect</strong> ставит своим абсолютным приоритетом цифровую приватность пользователей. Наша политика предельно прозрачна: мы не собираем и не храним информацию о вашей активности в сети, поэтому мы не можем никому ее передать.</p>

      <h3 style="color:var(--em-t);font-size:17px;margin-top:22px">1. Политика полного отсутствия журналов активности (Zero-Logs Policy)</h3>
      <p style="color:var(--mut)">Мы гарантируем строгое соблюдение принципа ненакопления данных сетевого взаимодействия. Серверные узлы Исполнителя технически настроены так, что мы не записываем, не храним и не передаем третьим лицам:</p>
      <ul style="padding-left:20px;line-height:1.8;color:var(--mut)">
        <li>Историю посещенных веб-сайтов, интернет-адреса и обращения к сервисам;</li>
        <li>Исходные IP-адреса абонентских устройств;</li>
        <li>Запросы системы доменных имен (DNS-запросы);</li>
        <li>Содержимое передаваемого трафика, файлов и личной переписки;</li>
        <li>Временные метки (timestamps) открытия и завершения соединений с конкретными ресурсами.</li>
      </ul>
      <p style="color:var(--mut);margin-top:10px"><strong style="color:var(--em-t)">Техническая реализация:</strong> На всех серверных узлах отключена фиксация журналов доступа (access-логи), а временные системные технические метрики операционной системы автоматически удаляются каждые 48 часов.</p>

      <h3 style="color:#fff;font-size:17px;margin-top:22px">2. Состав и цели обработки минимально необходимых сведений</h3>
      <p style="color:var(--mut)">В соответствии со ст. 5 Федерального закона № 152-ФЗ «О персональных данных» обработка ограничивается достижением конкретных, заранее определенных и законных целей предоставления доступа. Сервис обрабатывает исключительно необходимый технический минимум:</p>
      <ul style="padding-left:20px;line-height:1.8;color:var(--mut)">
        <li><strong style="color:#fff">Адрес электронной почты (Email):</strong> Используется исключительно для доставки индивидуального ключа доступа, направления фискальных расчетных документов и авторизации в личном кабинете.</li>
        <li><strong style="color:#fff">Telegram ID и Username:</strong> Сохраняются только при добровольном обращении Пользователя к официальному Telegram-боту сервиса для привязки уведомлений.</li>
        <li><strong style="color:#fff">Реквизиты заказов:</strong> Номер заказа, дата, сумма транзакции и выбранный тарифный план (необходимы для бухгалтерского и финансового учета).</li>
        <li><strong style="color:#fff">Служебные файлы Cookies:</strong> Временный токен авторизации в личном кабинете (<code>sc_web_token</code>) и маркер реферальной программы (<code>sc_ref</code>, 30 дней) для применения положенной скидки.</li>
        <li><strong style="color:#fff">Агрегированные счетчики трафика:</strong> Общий суммарный объем переданных байт без привязки к ресурсам или действиям, используемый исключительно для контроля соблюдения лимита устройств и стабильности сетевых каналов.</li>
      </ul>

      <h3 style="color:#fff;font-size:17px;margin-top:22px">3. Безопасность финансовых транзакций</h3>
      <p style="color:var(--mut)">Исполнитель <strong style="color:#fff">НЕ собирает, НЕ обрабатывает и НЕ хранит</strong> данные банковских карт Пользователей (номера карт, срок действия, CVV/CVC-коды). Все платежи проводятся непосредственно через защищенные платежные шлюзы сертифицированных банков-эквайеров и платежных провайдеров в соответствии со стандартами безопасности PCI DSS и регламентом Системы быстрых платежей (СБП / НСПК).</p>

      <h3 style="color:#fff;font-size:17px;margin-top:22px">4. Взаимодействие с государственными органами и третьими лицами</h3>
      <p style="color:var(--mut)">Мы соблюдаем применимое законодательство. Однако, в силу технической архитектуры Платформы и строгого соблюдения Zero-Logs Policy, мы физически не ведем и не накапливаем журналы сетевой активности и сопоставления трафика с конкретными пользователями. Сервис не имеет технической возможности раскрыть то, чем он не владеет.</p>

      <h3 style="color:#fff;font-size:17px;margin-top:22px">5. Права субъекта персональных данных</h3>
      <p style="color:var(--mut)">Пользователь вправе в любой момент отозвать свое согласие на обработку контактных данных и запросить полное удаление своей учетной записи и истории заказов, направив письменное заявление по официальному адресу <a href="mailto:support@silentconnect.net" style="color:var(--em-t);text-decoration:underline">support@silentconnect.net</a>. Данные удаляются в течение 72 часов с момента подтверждения запроса.</p>

      <h3 style="color:#fff;font-size:17px;margin-top:22px">6. Контакты службы поддержки</h3>
      <p style="color:var(--mut)">
        Электронная почта: <a href="mailto:support@silentconnect.net" style="color:var(--em-t);text-decoration:underline">support@silentconnect.net</a><br>
        Telegram-бот поддержки: <a href="https://t.me/SilentConnectSupport" style="color:var(--em-t);text-decoration:underline" target="_blank" rel="noopener">@SilentConnectSupport</a>
      </p>`
  },
  refund: {
    title: 'Политика возврата денежных средств и отмены подписки',
    date: 'Редакция от 5 сентября 2026 г. · Регламент взаиморасчетов (СБП / НСПК / Fair Use)',
    html: `
      <p>Мы стремимся обеспечить максимальный комфорт при использовании сервиса SilentConnect. Если сервис по техническим причинам вам не подошел, вы вправе запросить возврат денежных средств в рамках правил добросовестного использования (Fair Use Policy).</p>

      <h3 style="color:var(--em-t);font-size:17px;margin-top:22px">1. Гарантия возврата (Money-back Guarantee)</h3>
      <p style="color:var(--mut)">1.1. Исполнитель предоставляет гарантию возврата 100% уплаченных средств в течение <strong style="color:#fff">14 (четырнадцати) календарных дней</strong> с момента оплаты, если Пользователь не удовлетворен качеством работы сервиса.</p>
      <p style="color:var(--mut)">1.2. Гарантия возврата распространяется <strong style="color:#fff">исключительно на первый заказ (первую покупку)</strong>, совершенную с уникального аккаунта пользователя.</p>
      <p style="color:var(--mut)">1.3. Повторные покупки, продления действующей подписки, а также дополнительные заказы тем же пользователем (определяемым по email, Telegram ID либо платежным реквизитам) <strong style="color:#fff">возврату не подлежат</strong>. Факт повторной оплаты услуги юридически подтверждает полную удовлетворенность Пользователя качеством сервиса за предыдущие периоды.</p>

      <h3 style="color:#fff;font-size:17px;margin-top:22px">2. Условия отказа в возврате (Ограничения Fair Use)</h3>
      <p style="color:var(--mut)">Для защиты инфраструктуры от злоупотреблений и паразитарной нагрузки возврат средств не производится в следующих случаях:</p>
      <ul style="padding-left:20px;line-height:1.8;color:var(--mut)">
        <li><strong style="color:#fff">Лимит трафика (Data Cap):</strong> Если с момента генерации доступа через аккаунт прошло более <strong style="color:#fff">5 ГБ (Гигабайт)</strong> суммарного трафика. Превышение порога в 5 ГБ юридически признается Сторонами фактом полного потребления услуги и надлежащего качества соединения;</li>
        <li><strong style="color:#fff">Истечение срока:</strong> Обращение направлено позднее 14 календарных дней с момента совершения оплаты;</li>
        <li><strong style="color:#fff">Нарушение правил (AUP):</strong> Аккаунт был заблокирован за нарушение правил допустимого использования (спам, сканирование, атаки, реселлинг);</li>
        <li><strong style="color:#fff">Локальные ограничения клиента:</strong> Серверная инфраструктура исправна, но клиент не может настроить соединение из-за ограничений на стороне своего локального интернет-провайдера либо специфики личного устройства при условии, что служба поддержки предоставила инструкции и альтернативные конфигурации;</li>
        <li><strong style="color:#fff">Анонимные транзакции:</strong> Платежи, совершенные в криптовалюте, в силу необратимости блокчейн-транзакций возврату не подлежат (возможна компенсация дополнительными днями доступа).</li>
      </ul>

      <h3 style="color:#fff;font-size:17px;margin-top:22px">3. Регламент и процедура оформления возврата</h3>
      <p style="color:var(--mut)">3.1. Для оформления возврата направьте запрос по официальному адресу <a href="mailto:support@silentconnect.net" style="color:var(--em-t);text-decoration:underline">support@silentconnect.net</a> либо через верифицированный <a href="https://t.me/SilentConnectSupport" style="color:var(--em-t);text-decoration:underline" target="_blank" rel="noopener">Telegram-бот поддержки</a>.</p>
      <p style="color:var(--mut)">3.2. В обращении необходимо указать:</p>
      <ul style="padding-left:20px;line-height:1.8;color:var(--mut)">
        <li>Номер заказа (#ord_...) и контактный Email или Telegram ID;</li>
        <li>Дату и сумму оплаты, приложив чек или электронную квитанцию;</li>
        <li>Краткую причину обращения.</li>
      </ul>
      <p style="color:var(--mut)">3.3. Единственным объективным доказательством факта использования услуги являются серверные счетчики биллинга трафика. Скриншоты замера скорости сторонних утилит не требуются.</p>
      <p style="color:var(--mut)">3.4. Срок рассмотрения заявления службой поддержки составляет <strong style="color:#fff">до 48 часов</strong> (не более 3 рабочих дней).</p>
      <p style="color:var(--mut)">3.5. Выплата денежных средств осуществляется тем же способом, которым производилась оплата: через Систему быстрых платежей (СБП / НСПК) по номеру телефона плательщика либо на банковскую карту. Срок зачисления банком получателя составляет <strong style="color:#fff">от 1 до 3 банковских дней</strong>.</p>

      <h3 style="color:#fff;font-size:17px;margin-top:22px">4. Контакты службы поддержки</h3>
      <p style="color:var(--mut)">
        Электронная почта: <a href="mailto:support@silentconnect.net" style="color:var(--em-t);text-decoration:underline">support@silentconnect.net</a><br>
        Telegram-бот поддержки: <a href="https://t.me/SilentConnectSupport" style="color:var(--em-t);text-decoration:underline" target="_blank" rel="noopener">@SilentConnectSupport</a>
      </p>`
  }
};

function showLegalDoc(docId) {
  if (!LEGAL_DOCS[docId]) docId = 'refund';
  const doc = LEGAL_DOCS[docId];
  $$('#legalNav button').forEach(b => b.classList.toggle('on', b.dataset.doc === docId));
  const container = $('#legalDoc');
  if (container) {
    container.innerHTML = `<h2>${doc.title}</h2><div class="date">${doc.date}</div>${doc.html}`;
  }
  const nav = $('#legalNav');
  if (nav) centerActiveTab(nav);
}
window.showLegalDoc = showLegalDoc;

const legalNav = $('#legalNav');
if (legalNav) {
  setupDraggableTrack(legalNav);
  $$('#legalNav button').forEach(b => {
    b.addEventListener('click', () => showLegalDoc(b.dataset.doc));
  });
}
showLegalDoc('refund');

/* =========================================================================
   Cinematic Intro & Scroll Reveal (.rv)
   Плавное появление из атмосферного затемнения
   ========================================================================= */
function initScrollReveal() {
  const rvs = $$('.rv');
  if (!rvs.length) return;

  if (!('IntersectionObserver' in window)) {
    rvs.forEach(el => el.classList.add('in'));
    return;
  }

  const obs = new IntersectionObserver((entries, observer) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('in');
        observer.unobserve(entry.target);
      }
    });
  }, {
    rootMargin: '0px 0px -30px 0px',
    threshold: 0.05
  });

  rvs.forEach(el => obs.observe(el));

  // Immediate kick-off for above-the-fold elements
  requestAnimationFrame(() => {
    rvs.forEach(el => {
      const rect = el.getBoundingClientRect();
      if (rect.top < window.innerHeight * 0.95) {
        el.classList.add('in');
      }
    });
  });

  // Safety fallback after 1.2s in case of any observer glitch
  setTimeout(() => {
    $$('.rv:not(.in)').forEach(el => {
      const r = el.getBoundingClientRect();
      if (r.top < window.innerHeight) el.classList.add('in');
    });
  }, 1200);
}
window.initScrollReveal = initScrollReveal;
initScrollReveal();

})();
